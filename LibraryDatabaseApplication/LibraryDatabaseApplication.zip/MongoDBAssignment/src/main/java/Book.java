//Importing Serializable library
import java.io.Serializable;

//Declaring book class
public class Book implements Serializable{
    //Declaring the private variables BookName, Genre, Author and CurrentlyAvailable
    private String BookName;
    private String Genre;
    private String Author;
    private String CurrentlyAvailable;

    //Subroutine for getting the BookName
    public String getBookName(){ return BookName; }

    //Subroutine for setting the BookName
    public void setBookName(String BookName){ this.BookName = BookName; }

    //Subroutine for getting the Genre
    public String getGenre(){ return Genre; }

    //Subroutine for setting the Genre
    public void setGenre(String Genre){ this.Genre = Genre; }

    //Subroutine for getting the Author
    public String getAuthor(){ return Author; }

    //Subroutine for setting the Author
    public void setAuthor(String Author){ this.Author = Author; }

    //Subroutine for getting the availability status
    public String getCurrentlyAvailable(){ return CurrentlyAvailable; }

    //Subroutine for setting the availability status
    public void setCurrentlyAvailable(String CurrentlyAvailable){ this.CurrentlyAvailable = CurrentlyAvailable; }
}
