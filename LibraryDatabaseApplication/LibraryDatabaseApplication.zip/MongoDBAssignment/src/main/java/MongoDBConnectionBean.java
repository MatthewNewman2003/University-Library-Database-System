//Importing libraries
import jakarta.annotation.PostConstruct;
import jakarta.ejb.ConcurrencyManagement;
import jakarta.ejb.ConcurrencyManagementType;
import jakarta.ejb.Lock;
import jakarta.ejb.LockType;
import jakarta.ejb.Singleton;
import com.mongodb.MongoClient;

//Declaring singleton JavaBean named MongoDBConnectionBean
@Singleton(name = "MongoDBConnectionBean")
@ConcurrencyManagement(ConcurrencyManagementType.CONTAINER)
public class MongoDBConnectionBean {
    //Subroutine for initialising the ConnectionBean
    public MongoDBConnectionBean(){

    }

    //Declaring MongoDB connection
    private MongoClient MongoConnection = null;

    //Subroutine for fetching the MongoDB connection
    @Lock(LockType.READ)
    public MongoClient getMongoClient(){
        return MongoConnection;
    }

    //Subroutine for initialising the MongoDB connection
    @PostConstruct
    public void init(){
        String IPAddress = "localhost";
        Integer Port = 27017;
        MongoConnection = new MongoClient(IPAddress, Port);
    }
}
