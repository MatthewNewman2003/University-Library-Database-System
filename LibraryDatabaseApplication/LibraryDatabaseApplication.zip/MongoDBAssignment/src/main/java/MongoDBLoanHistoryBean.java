//Importing libraries
import com.mongodb.MongoClient;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import jakarta.ejb.EJB;
import jakarta.ejb.Stateless;
import org.bson.Document;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;

//Declaring stateless JavaBean named MongoDBLoanHistoryBean
@Stateless(name="MongoDBLoanHistoryBean")
public class MongoDBLoanHistoryBean {
    //Declaring ConnectionBean to connect to MongoDB
    @EJB
    MongoDBConnectionBean MongoDBConnection;

    //Subroutine for initialising LoanHistoryBean
    public MongoDBLoanHistoryBean(){

    }

    //Subroutine for finding loan history
    public AggregateIterable<Document> FindLoanHistory(Date Month, String EmailAddress){
        //Connecting to MongoDB
        MongoClient MongoConnection = MongoDBConnection.getMongoClient();

        //Fetching the library database
        MongoDatabase LibraryDatabase = MongoConnection.getDatabase("LibraryDatabase");

        //Fetching the loans collection
        MongoCollection<Document> LoansCollection = LibraryDatabase.getCollection("LoansCollection");

        //Setting the given month as a date
        Calendar Days = Calendar.getInstance();
        Days.setTime(Month);

        //Fetching the month and year of the given month
        Integer YearOfMonth = Days.get(Days.YEAR);
        Integer MonthOfMonth = Days.get(Days.MONTH) + 1;

        //Constructing aggregate pipeline to find the user's loan history for a given month
        AggregateIterable<Document> LoanHistory = LoansCollection.aggregate(Arrays.asList(
                new Document("$project", new Document("LoanName", 1)
                        .append("EmailAddress", 1)
                        .append("BookName", 1)
                        .append("LoanDate", 1)
                        .append("DueDate", 1)
                        .append("ReturnDate", 1)
                        .append("ReturnedOnTime", 1)
                        .append("Month", new Document("$month", "$LoanDate"))
                        .append("Year", new Document("$year", "$LoanDate"))),
                new Document("$match", Filters.and(Filters.eq("EmailAddress", EmailAddress),
                        Filters.eq("Month", MonthOfMonth),
                        Filters.eq("Year", YearOfMonth)))
        ));

        //Returning the result
        return LoanHistory;
    }
}
