//Importing libraries
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import org.bson.Document;
import jakarta.ejb.Stateless;
import jakarta.ejb.EJB;
import org.bson.conversions.Bson;
import java.util.Date;
import static com.mongodb.client.model.Filters.eq;

//Declaring stateless JavaBean named MongoDBBookReturnBean
@Stateless(name = "MongoDBBookReturnBean")
public class MongoDBBookReturnBean {
    //Declaring ConnectionBean to connect to MongoDB
    @EJB MongoDBConnectionBean MongoDBConnection;

    //Subroutine for initialising BookReturnBean
    public MongoDBBookReturnBean(){

    }

    //Subroutine for finding a loan
    public FindIterable<Document> FindLoan(String LoanName){
        //Connecting to MongoDB
        MongoClient MongoConnection = MongoDBConnection.getMongoClient();

        //Fetching the library database
        MongoDatabase LibraryDatabase = MongoConnection.getDatabase("LibraryDatabase");

        //Fetching the loans collection
        MongoCollection<Document> LoansCollection = LibraryDatabase.getCollection("LoansCollection");

        //Filtering the database to only show the loan with a given name
        Bson Query = eq("LoanName", LoanName);

        //Applying the filter to the loans collection and finding the loan with the given loan name
        FindIterable<Document> IsLoanPresent = LoansCollection.find(Query);

        //Returning the result
        return IsLoanPresent;
    }

    //Subroutine for checking if a book is unreturned
    public boolean IsBookUnreturned(Document Loan){
        //Fetching the return date of the found loan
        String ReturnDate = Loan.getString("ReturnDate");

        //Checking if the return date is blank (if the return date is blank, the book is unreturned)
        Boolean IsBookUnreturned = ReturnDate.isBlank();

        //Returning the result
        return IsBookUnreturned;
    }

    //Checking if a return is late
    public boolean IsReturnLate(Document Loan, Date ReturnDate){
        //Fetching due date from the given loan
        Date DueDate = Loan.getDate("DueDate");

        //Checking if the return date is after the due date (if it is, the book has been returned late)
        Boolean LateOrNot = ReturnDate.after(DueDate);

        //Returning the result
        return LateOrNot;
    }

    //Subroutine for returning a book late
    public void LateReturn(String LoanName, Date ReturnDate, String BookName){
        //Connecting to MongoDB
        MongoClient MongoConnection = MongoDBConnection.getMongoClient();

        //Fetching the library database
        MongoDatabase LibraryDatabase = MongoConnection.getDatabase("LibraryDatabase");

        //Fetching the loans collection
        MongoCollection<Document> LoansCollection = LibraryDatabase.getCollection("LoansCollection");

        //Filtering the database to only show the loan with a given name
        Bson Query = Filters.eq("LoanName", LoanName);

        //Declaring an update query to add the return date of a loan and set ReturnedOnTime and FinePaid to No
        Bson UpdatedValues = Updates.combine(Updates.set("ReturnDate", ReturnDate), Updates.set("ReturnedOnTime", "No"), Updates.set("FinePaid", "No"));

        //Applying the update query to the loan with the given name
        LoansCollection.updateOne(Query, UpdatedValues);

        //Fetching the books collection
        MongoCollection<Document> BooksCollection = LibraryDatabase.getCollection("BooksCollection");

        //Filtering the database to only show the book with a given name
        Bson BookQuery = Filters.eq("BookName", BookName);

        //Declaring an update query to update the book's CurrentlyAvailable status to Yes
        Bson UpdatedValue = Updates.set("CurrentlyAvailable", "Yes");

        //Applying the update to the book with the given name
        BooksCollection.updateOne(BookQuery, UpdatedValue);
    }

    //Subroutine for returning a book on time
    public void PunctualReturn(String LoanName, Date ReturnDate, String BookName){
        //Connecting to MongoDB
        MongoClient MongoConnection = MongoDBConnection.getMongoClient();

        //Fetching the library database
        MongoDatabase LibraryDatabase = MongoConnection.getDatabase("LibraryDatabase");

        //Fetching the loans collection
        MongoCollection<Document> LoansCollection = LibraryDatabase.getCollection("LoansCollection");

        //Filtering the database to only show the loan with a given name
        Bson Query = Filters.eq("LoanName", LoanName);

        //Declaring update query to add the return date of a loan and set ReturnedOnTime to Yes
        Bson UpdatedValues = Updates.combine(Updates.set("ReturnDate", ReturnDate), Updates.set("ReturnedOnTime", "Yes"));

        //Applying the update to the loans collection
        LoansCollection.updateOne(Query, UpdatedValues);

        //Fetching books collection
        MongoCollection<Document> BooksCollection = LibraryDatabase.getCollection("BooksCollection");

        //Filtering the database to only show the book with a given name
        Bson BookQuery = Filters.eq("BookName", BookName);

        //Declaring update query to set the book's CurrentlyAvailable status to Yes
        Bson UpdatedValue = Updates.set("CurrentlyAvailable", "Yes");

        //Applying the update to the book with the given name
        BooksCollection.updateOne(BookQuery, UpdatedValue);
    }
}
