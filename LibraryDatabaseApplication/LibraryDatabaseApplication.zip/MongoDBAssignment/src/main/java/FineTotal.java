//Importing Serializable library
import java.io.Serializable;

//Declaring FineTotal class
public class FineTotal implements Serializable{
    //Declaring private variable TotalFine
    private Integer TotalFine;

    //Subroutine for getting TotalFine
    public Integer getTotalFine(){ return TotalFine; }

    //Subroutine for setting TotalFine
    public void setTotalFine(Integer TotalFine){ this.TotalFine = TotalFine; }
}
