//Importing libraries
import jakarta.ejb.EJB;
import jakarta.ejb.Stateless;
import java.sql.*;
import java.util.ArrayList;

//Declaring stateless JavaBean named OracleRegistrationBean
@Stateless(name="OracleRegistrationBean")
public class OracleRegistrationBean {
    //Declaring ConnectionBean to connect to Oracle
    @EJB
    OracleConnectionBean OracleConnection;

    //Subroutine for initialising the RegistrationBean
    public OracleRegistrationBean(){

    }

    //Subroutine for finding a student
    public ArrayList<Student> FindStudent(Student NewStudent){
        //Declaring SQL query to find a student with a given email address
        String Query = "SELECT * FROM StudentsTable WHERE EmailAddress = ?";

        //Declaring array list to store the results
        ArrayList ResultsList = new ArrayList();
        try{
            //Connecting to Oracle
            Connection OracleConnect = OracleConnection.GetOracleConnection();
            //Preparing a statement based on the SQL query
            PreparedStatement SQLQuery = OracleConnect.prepareStatement(Query);
            //Setting the parameter value of the prepared statement
            SQLQuery.setString(1, NewStudent.getEmailAddress());
            //Executing the SQL query
            ResultSet Result = SQLQuery.executeQuery();

            //Appending each student found into the results list
            while(Result.next()){
                Student FoundStudent = new Student();
                FoundStudent.setEmailAddress(Result.getString("EmailAddress"));
                FoundStudent.setFirstName(Result.getString("FirstName"));
                FoundStudent.setLastName(Result.getString("LastName"));
                FoundStudent.setPassword(Result.getString("Password"));
                ResultsList.add(FoundStudent);
            }

            System.out.println("Finding existing students.");

            //Closing the SQL query
            SQLQuery.close();

            //Returning the results
            return ResultsList;
        } catch(SQLException Exception){
            //Outcome if an SQL exception is thrown
            System.out.println("SQL Exception occurred.");
            Exception.printStackTrace();
        }
        //Returning the results
        return ResultsList;
    }

    //Subroutine for registering a student
    public void RegisterStudent(Student NewStudent){
        //Declaring SQL query to register a student into the database
        String Query = "INSERT INTO StudentsTable (EmailAddress, FirstName, LastName, Password) VALUES (?, ?, ?, ?)";
        try{
            //Connecting to Oracle
            Connection OracleConnect = OracleConnection.GetOracleConnection();
            //Preparing a statement based on the SQL query
            PreparedStatement SQLQuery = OracleConnect.prepareStatement(Query);
            //Setting the parameter values of the prepared statement
            SQLQuery.setString(1, NewStudent.getEmailAddress());
            SQLQuery.setString(2, NewStudent.getFirstName());
            SQLQuery.setString(3, NewStudent.getLastName());
            SQLQuery.setString(4, NewStudent.getPassword());

            //Executing the SQL query
            SQLQuery.executeUpdate();

            System.out.println("Student inserted.");

            //Closing the SQL query
            SQLQuery.close();
        } catch(SQLException Exception){
            //Outcome if an SQL exception is thrown
            System.out.println("SQL Exception thrown.");
            Exception.printStackTrace();
        }
    }
}
