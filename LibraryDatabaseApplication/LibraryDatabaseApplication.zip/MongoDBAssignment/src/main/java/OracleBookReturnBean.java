//Importing libraries
import jakarta.ejb.Stateless;
import jakarta.ejb.EJB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

//Declaring stateless JavaBean named OracleBookReturnBean
@Stateless(name="OracleBookReturnBean")
public class OracleBookReturnBean {
    //Declaring ConnectionBean to connect to Oracle
    @EJB OracleConnectionBean OracleConnection;

    //Subroutine to initialise the BookReturnBean
    public OracleBookReturnBean(){

    }

    //Subroutine for finding a loan
    public ArrayList<Loan> FindLoan(String LoanName){
        //Declaring SQL query for finding the loan with a given name within the database
        String Query = "SELECT * FROM LoansTable WHERE LoanName = ?";

        //Declaring array list to store the results
        ArrayList ResultsList = new ArrayList();
        try{
            //Connecting to Oracle
            Connection OracleConnect = OracleConnection.GetOracleConnection();
            //Preparing a statement based on the SQL query
            PreparedStatement SQLQuery = OracleConnect.prepareStatement(Query);
            //Setting the parameter value of the prepared statement
            SQLQuery.setString(1, LoanName);
            //Executing the SQL query
            ResultSet Result = SQLQuery.executeQuery();

            //Appending any found loans into the results list
            while(Result.next()){
                Loan FoundLoan = new Loan();
                FoundLoan.setLoanName(Result.getString("LoanName"));
                FoundLoan.setEmailAddress(Result.getString("EmailAddress"));
                FoundLoan.setBookName(Result.getString("BookName"));
                FoundLoan.setLoanDate(Result.getDate("LoanDate"));
                FoundLoan.setDueDate(Result.getDate("DueDate"));
                FoundLoan.setReturnDate(Result.getDate("ReturnDate"));
                FoundLoan.setReturnedOnTime(Result.getString("ReturnedOnTime"));
                FoundLoan.setFinePaid(Result.getString("FinePaid"));
                ResultsList.add(FoundLoan);
            }

            System.out.println("Finding existing loans.");

            //Closing the SQL query
            SQLQuery.close();

            //Returning the results
            return ResultsList;
        } catch(SQLException Exception){
            //Outcome if an SQL exception is thrown
            System.out.println("SQL Exception occurred.");
            Exception.printStackTrace();
        }
        //Returning the results
        return ResultsList;
    }

    //Subroutine for checking if a book is unreturned
    public boolean IsBookUnreturned(String LoanName){
        //Declaring SQL query for searching for a loan with a given name and a non-null ReturnDate
        String Query = "SELECT * FROM LoansTable WHERE LoanName=? and ReturnDate IS NOT NULL";

        //Declaring an array list to store the results
        ArrayList<Loan> MatchingLoans = new ArrayList();
        try{
            //Connecting to Oracle
            Connection OracleConnect = OracleConnection.GetOracleConnection();
            //Preparing a statement based on the SQL query
            PreparedStatement SQLQuery = OracleConnect.prepareStatement(Query);
            //Setting the parameter value of the prepared statement
            SQLQuery.setString(1,LoanName);
            //Executing the SQL query
            ResultSet Result = SQLQuery.executeQuery();

            //Appending any found loans into the results list
            while(Result.next()){
                Loan FoundLoan = new Loan();
                FoundLoan.setLoanName(Result.getString("LoanName"));
                FoundLoan.setEmailAddress(Result.getString("EmailAddress"));
                FoundLoan.setBookName(Result.getString("BookName"));
                FoundLoan.setLoanDate(Result.getDate("LoanDate"));
                FoundLoan.setDueDate(Result.getDate("DueDate"));
                MatchingLoans.add(FoundLoan);
            }

            System.out.println("Checking if book has been returned.");

            //Closing the SQL query
            SQLQuery.close();
        } catch(SQLException Exception){
            //Outcome if an SQL exception is thrown
            System.out.println("SQL Exception occurred.");
            Exception.printStackTrace();
        }

        //Checking if the results list is empty (if it is, the book is unreturned)
        Boolean IsBookUnreturned = MatchingLoans.isEmpty();

        //Returning the results
        return IsBookUnreturned;
    }

    //Subroutine for checking if a book was returned late
    public boolean IsReturnLate(Loan MatchingLoan, java.sql.Date ReturnDate){
        //Fetching the due date of the loan
        java.sql.Date DueDate = MatchingLoan.getDueDate();

        //Checking if the return date is after the due date (if it is, the book has been returned late)
        Boolean LateOrNot = ReturnDate.after(DueDate);

        //Returning the results
        return LateOrNot;
    }

    //Subroutine for returning a book late
    public void LateReturn(String LoanName, java.sql.Date ReturnDate, String BookName){
        //Declaring SQL query for adding a return date to a given loan and setting its ReturnedOnTime and FinePaid statuses
        String Query = "UPDATE LoansTable SET ReturnDate=?, ReturnedOnTime=?, FinePaid=? WHERE LoanName=?";

        try{
            //Connecting to Oracle
            Connection OracleConnect = OracleConnection.GetOracleConnection();
            //Preparing a statement based on the SQL query
            PreparedStatement SQLQuery = OracleConnect.prepareStatement(Query);
            //Setting the parameter values of the prepared statement
            SQLQuery.setDate(1,ReturnDate);
            SQLQuery.setString(2, "No");
            SQLQuery.setString(3, "No");
            SQLQuery.setString(4, LoanName);

            //Executing the SQL query
            SQLQuery.executeUpdate();

            System.out.println("Returning book late.");

            //Closing the SQL query
            SQLQuery.close();
        } catch(SQLException Exception){
            //Outcome if an SQL exception is thrown
            System.out.println("SQL Exception occurred.");
            Exception.printStackTrace();
        }

        //Declaring SQL query to update a given book's CurrentlyAvailable status
        String BookQuery = "UPDATE BooksTable SET CurrentlyAvailable=? WHERE BookName=?";
        try{
            //Connecting to Oracle
            Connection OracleConnect = OracleConnection.GetOracleConnection();
            //Preparing a statement based on the SQL query
            PreparedStatement SQLQuery = OracleConnect.prepareStatement(BookQuery);
            //Setting the parameter values of the prepared statement
            SQLQuery.setString(1, "Yes");
            SQLQuery.setString(2, BookName);

            //Executing the SQL query
            SQLQuery.executeUpdate();

            System.out.println("Making book available again.");

            //Closing the SQL query
            SQLQuery.close();
        } catch(SQLException Exception){
            //Outcome if an SQL exception is thrown
            System.out.println("SQL Exception occurred.");
            Exception.printStackTrace();
        }
    }

    //Subroutine for returning a book on time
    public void PunctualReturn(String LoanName, java.sql.Date ReturnDate, String BookName){
        //Declaring SQL query to add the return date of a given loan and set its ReturnedOnTime status
        String Query = "UPDATE LoansTable SET ReturnDate=?, ReturnedOnTime=? WHERE LoanName=?";

        try{
            //Connecting to Oracle
            Connection OracleConnect = OracleConnection.GetOracleConnection();
            //Preparing statement based on the SQL query
            PreparedStatement SQLQuery = OracleConnect.prepareStatement(Query);
            //Setting the parameter values of the prepared statement
            SQLQuery.setDate(1,ReturnDate);
            SQLQuery.setString(2, "Yes");
            SQLQuery.setString(3, LoanName);

            //Executing the SQL query
            SQLQuery.executeUpdate();

            System.out.println("Returning book on time.");

            //Closing the SQL query
            SQLQuery.close();
        } catch(SQLException Exception){
            //Outcome if an SQL exception occurs
            System.out.println("SQL Exception occurred.");
            Exception.printStackTrace();
        }

        //Declaring SQL query to update the CurrentlyAvailable status of a book
        String BookQuery = "UPDATE BooksTable SET CurrentlyAvailable=? WHERE BookName=?";
        try{
            //Connecting to Oracle
            Connection OracleConnect = OracleConnection.GetOracleConnection();
            //Preparing a statement based on the SQL query
            PreparedStatement SQLQuery = OracleConnect.prepareStatement(BookQuery);
            //Setting parameter values of prepared statement
            SQLQuery.setString(1, "Yes");
            SQLQuery.setString(2, BookName);

            //Executing the SQL query
            SQLQuery.executeUpdate();

            System.out.println("Making book available again.");

            //Closing the SQL query
            SQLQuery.close();
        } catch(SQLException Exception){
            //Outcome if an SQL exception is thrown
            System.out.println("SQL Exception occurred.");
            Exception.printStackTrace();
        }
    }
}
