//Importing Serializable library
import java.io.Serializable;

//Declaring Fine class
public class Fine implements Serializable {
    //Declaring the private variables LoanName, EmailAddress, FineDate and FineAmount
    private String LoanName;
    private String EmailAddress;
    private java.sql.Date FineDate;
    private Integer FineAmount;

    //Subroutine for getting the LoanName
    public String getLoanName(){ return LoanName; }

    //Subroutine for setting the LoanName
    public void setLoanName(String LoanName){ this.LoanName=LoanName; }

    //Subroutine for getting the EmailAddress
    public String getEmailAddress(){ return EmailAddress; }

    //Subroutine for setting the EmailAddress
    public void setEmailAddress(String EmailAddress){ this.EmailAddress=EmailAddress; }

    //Subroutine for getting the FineDate
    public java.sql.Date getFineDate(){ return FineDate; }

    //Subroutine for setting the FineDate
    public void setFineDate(java.sql.Date FineDate){ this.FineDate=FineDate; }

    //Subroutine for getting the FineAmount
    public Integer getFineAmount(){ return FineAmount; }

    //Subroutine for setting the FineAmount
    public void setFineAmount(Integer FineAmount){ this.FineAmount=FineAmount; }
}
