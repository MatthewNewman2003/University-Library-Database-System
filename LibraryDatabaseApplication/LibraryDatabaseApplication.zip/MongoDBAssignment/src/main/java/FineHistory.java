//Importing libraries
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.MongoCursor;
import jakarta.ejb.EJB;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import org.bson.Document;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

//Declaring a servlet named FineHistory
@WebServlet(name = "FineHistory", value = "/FineHistory")
public class FineHistory extends HttpServlet {
    //Declaring FineHistoryBeans for MongoDB and Oracle
    @EJB
    MongoDBFineHistoryBean MongoDBFineHistory;
    @EJB
    OracleFineHistoryBean OracleFineHistory;

    //Declaring the two database types for the servlet
    enum DatabaseType{
        ORACLE, MONGODB;
    }

    //Setting the database type for the servlet
    //By default, this is set to Oracle, but can be changed to MongoDB
    private FineHistory.DatabaseType Database = FineHistory.DatabaseType.ORACLE;

    //Declaring subroutine for performing GET requests (as none are performed here, this is empty)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    //Declaring subroutine for performing POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Fetching session data and extracting the user's email address from this
        HttpSession session = request.getSession();
        Object EmailAddress = session.getAttribute("EmailAddress");

        //Converting email address to a string and fetching the user's inputted month
        String EmailAddressStr = EmailAddress.toString();
        String MonthStr = request.getParameter("Month");

        //Declaring a null date to represent the Month
        Date Month = null;
        //Trying to parse the date string and convert it into a valid date
        //If the string cannot be converted, a ParseException is thrown
        try {
            SimpleDateFormat DateConverter = new SimpleDateFormat("yyyy-MM");
            Month = DateConverter.parse(MonthStr);
        }catch(ParseException exp){
            exp.printStackTrace();
        }

        //Outcome if DatabaseType is set to MongoDB
        if(Database == DatabaseType.MONGODB){
            //Finding the user's fine history for the inputted month and finding the result
            AggregateIterable<Document> FindFineHistory = MongoDBFineHistory.FindFineHistory(Month, EmailAddressStr);
            Document AnyFineHistory = FindFineHistory.first();

            //Calculating the total fine the user has paid for the inputted month and finding the result
            AggregateIterable<Document> TotalFinePaid = MongoDBFineHistory.CalculateTotalFine(Month, EmailAddressStr);
            Document TotalFine = TotalFinePaid.first();

            //Outcome if the user has any fine history for the given month
            if(AnyFineHistory != null){
                //Outputting all the user's fines for the month on the page
                MongoCursor<Document> Cursor = FindFineHistory.iterator();
                String Message = "<h2>You paid the following fines during the inputted month: </h2>";
                //Outputting all the user's fines on the page with the relevant information
                try{
                    //While there is still another fine present, the cursor outputs the next fine on the page
                    while(Cursor.hasNext()){
                        Document Fine = Cursor.next();

                        Message = Message + "<br>"
                                + "Loan Name: " + Fine.get("LoanName") + "<br>"
                                + "Fine Date: " + Fine.get("FineDate") + "<br>"
                                + "Fine Amount: £" + Fine.get("FineAmount") + "<br>"
                                + "<hr>";
                    }
                }finally{
                    //When all the fines have been outputted, the cursor is closed
                    Cursor.close();
                }
                //Outputting the total amount of fine paid by the user on the page
                Message = Message + "<br>"
                        + "<h2> The total amount of fine you paid during the inputted month is: £" + TotalFine.get("TotalFine")
                        + "</h2>" + "<hr>";
                request.setAttribute("Message", Message);
                request.getRequestDispatcher("FineHistoryPage.jsp").forward(request, response);
            } else{
                //If no fines were paid during the month, the user is informed of this and encouraged to try a different month
                String Message = "You did not pay any fines during this month. Please try a different month.";
                request.setAttribute("Message", Message);
                request.getRequestDispatcher("FineHistoryPage.jsp").forward(request, response);
            }
        } else{
            //If the DatabaseType is set to Oracle, the user's fine history for the month is found and put into an ArrayList
            ArrayList<Fine> FineHistory = OracleFineHistory.FindFineHistory(Month, EmailAddressStr);
            //Outcome if the user paid no fines during the month
            if(FineHistory.isEmpty()){
                //Informing the user of their empty fine history for the month and encouraging them to try a different month
                String Message = "You did not pay any fines during this month. Please try a different month.";
                request.setAttribute("Message", Message);
                request.getRequestDispatcher("FineHistoryPage.jsp").forward(request, response);
            } else {
                //If fines are found for the month, the total fine amount paid is firstly calculated
                ArrayList<FineTotal> TotalFine = OracleFineHistory.CalculateTotalFine(Month, EmailAddressStr);
                FineTotal TotalFineValue = TotalFine.get(0);

                //Iterating through the fines and outputting each one onto the page individually
                Iterator<Fine> Cursor = FineHistory.iterator();
                String Message = "<h2>You paid the following fines during the inputted month: </h2>";
                while (Cursor.hasNext()) {
                    Fine FoundFine = new Fine();
                    FoundFine = (Fine) Cursor.next();

                    Message = Message + "<br>"
                            + "Loan Name: " + FoundFine.getLoanName() + "<br>"
                            + "Fine Date: " + FoundFine.getFineDate() + "<br>"
                            + "Fine Amount: £" + FoundFine.getFineAmount() + "<br>"
                            + "<hr>";
                }
                //Outputting the total fine amount paid on the page
                Message = Message + "<br>"
                        + "<h2> The total amount of fine you paid during the inputted month is: £" + TotalFineValue.getTotalFine()
                        + "</h2>" + "<hr>";
                request.setAttribute("Message", Message);
                request.getRequestDispatcher("FineHistoryPage.jsp").forward(request, response);
            }
        }
    }
}