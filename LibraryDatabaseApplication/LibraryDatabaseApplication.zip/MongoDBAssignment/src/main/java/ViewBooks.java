//Importing libraries
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCursor;
import jakarta.ejb.EJB;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.bson.Document;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

//Declaring servlet named ViewBooks
@WebServlet(name = "ViewBooks", value = "/ViewBooks")
public class ViewBooks extends HttpServlet {
    //Declaring ViewBooksBeans for MongoDB and Oracle
    @EJB
    MongoDBViewBooksBean MongoDBViewBooks;
    @EJB
    OracleViewBooksBean OracleViewBooks;

    //Declaring the two database types for the servlet
    enum DatabaseType{
        ORACLE, MONGODB;
    }

    //Setting database type for the Servlet
    //This is set to Oracle by default, but can be changed to MongoDB
    private ViewBooks.DatabaseType Database = ViewBooks.DatabaseType.ORACLE;

    //Subroutine for handling GET requests (as none are sent here, this is empty)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    //Subroutine for handling POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Outcome if the database type is MongoDB
        if(Database == DatabaseType.MONGODB){
            //Finding books and providing the result
            FindIterable<Document> FindBooks = MongoDBViewBooks.FindBooks();
            Document AnyBooks = FindBooks.first();
            //Outcome if books are found
            if(AnyBooks != null){
                //Iterating through the books and outputting each book onto the page
                MongoCursor<Document> Cursor = FindBooks.iterator();
                String Message = "<h2>The following books are present within the database: </h2>";
                try{
                    while(Cursor.hasNext()){
                        Document Book = Cursor.next();

                        Message = Message + "<br>"
                                + "Book Name: " + Book.get("BookName") + "<br>"
                                + "Genre: " + Book.get("Genre") + "<br>"
                                + "Author: " + Book.get("Author") + "<br>"
                                + "Currently Available?: " + Book.get("CurrentlyAvailable") + "<br>"
                                + "<hr>";
                    }
                }finally{
                    Cursor.close();
                }
                request.setAttribute("Message", Message);
                request.getRequestDispatcher("ViewBooksPage.jsp").forward(request, response);
            } else{
                //If no books are found, the user is informed of this
                String Message = "No books found.";
                request.setAttribute("Message", Message);
                request.getRequestDispatcher("ViewBooksPage.jsp").forward(request, response);
            }
        } else{
            //If the database type is Oracle, the database is searched for books
            ArrayList<Book> Books = OracleViewBooks.FindBooks();
            //Outcome if no books are found
            if(Books.isEmpty()){
                //If no books are found, the user is informed of this
                String Message = "No books found.";
                request.setAttribute("Message", Message);
                request.getRequestDispatcher("ViewBooksPage.jsp").forward(request, response);
            } else{
                //If books are found, the array of books is iterated through and each book is outputted on the page
                Iterator<Book> Cursor = Books.iterator();
                String Message = "<h2>The following books are present within the database: </h2>";
                while(Cursor.hasNext()){
                    Book FoundBook = new Book();
                    FoundBook = (Book)Cursor.next();


                    Message = Message + "<br>"
                            + "Book Name: " + FoundBook.getBookName() + "<br>"
                            + "Genre: " + FoundBook.getGenre() + "<br>"
                            + "Author: " + FoundBook.getAuthor() + "<br>"
                            + "Currently Available?: " + FoundBook.getCurrentlyAvailable() + "<br>"
                            + "<hr>";
                }
                request.setAttribute("Message", Message);
                request.getRequestDispatcher("ViewBooksPage.jsp").forward(request, response);
            }
        }


    }
}