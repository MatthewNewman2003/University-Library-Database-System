//Importing libraries
import com.mongodb.client.*;
import jakarta.ejb.EJB;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import org.bson.Document;

//Declaring servlet named ReturnABook
@WebServlet(name = "ReturnABook", value = "/ReturnABook")
public class ReturnABook extends HttpServlet {
    //Declaring BookReturnBeans for MongoDB and Oracle
    @EJB
    MongoDBBookReturnBean MongoDBBookReturn;
    @EJB
    OracleBookReturnBean OracleBookReturn;

    //Declaring the two data sources used by the servlet
    enum DatabaseType{
        ORACLE, MONGODB;
    }

    //Setting the data source used by the servlet
    //This is set to Oracle by default, but can be changed to MongoDB
    private ReturnABook.DatabaseType Database = ReturnABook.DatabaseType.ORACLE;

    //Subroutine for handling GET requests (as none occur here, this is empty)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    //Subroutine for handling POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Setting response type to HTML text
        response.setContentType("text/html");

        //Fetching loan name and return date from request
        String LoanName = request.getParameter("LoanName");
        String ReturnDateStr = request.getParameter("ReturnDate");

        //Declaring ReturnDate as a null Date variable
        Date ReturnDate = null;
        //Trying to convert the date string into a date
        //If it cannot be converted, a parse exception is thrown
        try {
            SimpleDateFormat DateConverter = new SimpleDateFormat("yyyy-MM-dd");
            ReturnDate = DateConverter.parse(ReturnDateStr);
        }catch(ParseException exp){
            exp.printStackTrace();
        }

        //Outcome if data source is MongoDB
        if(Database == DatabaseType.MONGODB){
            //Finding a loan with the given name and providing the result
            FindIterable<Document> FindLoan = MongoDBBookReturn.FindLoan(LoanName);
            Document Result = FindLoan.first();
            //Outcome if a loan with the given name is found
            if(Result != null){
                //The loan is checked to see if the book has been returned
                Boolean HasBookBeenReturned = MongoDBBookReturn.IsBookUnreturned(Result);
                //Outcome if book is unreturned
                if(HasBookBeenReturned){
                    //Checking if book was returned late
                    Boolean IsReturnLate = MongoDBBookReturn.IsReturnLate(Result, ReturnDate);
                    //Outcome if book was returned late
                    if(IsReturnLate) {
                        //Returning the book and informing the user that they must pay a £50 fine
                        String BookName = Result.getString("BookName");
                        MongoDBBookReturn.LateReturn(LoanName,ReturnDate,BookName);
                        String Message = "This book has been returned late. You must pay a £50 fine.";
                        request.setAttribute("Message", Message);
                        request.getRequestDispatcher("ReturnABookPage.jsp").forward(request, response);
                    } else {
                        //If the book was returned on time, the book is returned and the user is informed that no fine is required
                        String BookName = Result.getString("BookName");
                        MongoDBBookReturn.PunctualReturn(LoanName,ReturnDate,BookName);
                        String Message = "This book has been returned on time. No fine is required.";
                        request.setAttribute("Message", Message);
                        request.getRequestDispatcher("ReturnABookPage.jsp").forward(request, response);
                    }
                }else{
                    //If the book has already been returned, the user is informed that they do not need to return it again
                    String Message = "This book has already been returned. You do not need to return it again.";
                    request.setAttribute("Message", Message);
                    request.getRequestDispatcher("ReturnABookPage.jsp").forward(request, response);
                }
            } else {
                //If the loan name does not exist, the user is informed of this and encouraged to provide one that does exist
                String Message = "This loan name does not exist. Please provide a loan name that does exist.";
                request.setAttribute("Message", Message);
                request.getRequestDispatcher("ReturnABookPage.jsp").forward(request, response);
            }
        } else{
            //If the data source is Oracle, the ReturnDate is converted into an SQL date
            java.sql.Date ReturnDateSQL = new java.sql.Date(ReturnDate.getTime());

            //Finding the loan with the given loan name
            ArrayList<Loan> FindLoan = OracleBookReturn.FindLoan(LoanName);
            //Outcome if no matching loan is found
            if(FindLoan.isEmpty()) {
                //Informing the user that the inputted loan name does not exist and encouraging them to provide one that does
                String Message = "This loan name does not exist. Please provide a loan name that does exist.";
                request.setAttribute("Message", Message);
                request.getRequestDispatcher("ReturnABookPage.jsp").forward(request, response);
            }else {
                //Fetching the matching loan and checking whether it is unreturned
                Loan MatchingLoan = FindLoan.get(0);
                Boolean IsBookUnreturned = OracleBookReturn.IsBookUnreturned(LoanName);
                //Outcome if book is unreturned
                if(IsBookUnreturned){
                    //Checking if book is being returned late
                    Boolean IsReturnLate = OracleBookReturn.IsReturnLate(MatchingLoan, ReturnDateSQL);
                    //Outcome if the return is late
                    if(IsReturnLate){
                        //Returning the book and informing the user that they must pay a £50 fine
                        String BookName = MatchingLoan.getBookName();
                        OracleBookReturn.LateReturn(LoanName, ReturnDateSQL, BookName);
                        String Message = "This book has been returned late. You must pay a £50 fine.";
                        request.setAttribute("Message", Message);
                        request.getRequestDispatcher("ReturnABookPage.jsp").forward(request, response);
                    } else{
                        //If the book has been returned on time, the book is returned and the user is informed that no fine is required
                        String BookName = MatchingLoan.getBookName();
                        OracleBookReturn.PunctualReturn(LoanName, ReturnDateSQL, BookName);
                        String Message = "This book has been returned on time. No fine is required.";
                        request.setAttribute("Message", Message);
                        request.getRequestDispatcher("ReturnABookPage.jsp").forward(request, response);
                    }
                } else{
                    //If the book has already been returned, the user is informed that they do not need to return it again
                    String Message = "This book has already been returned. You do not need to return it again.";
                    request.setAttribute("Message", Message);
                    request.getRequestDispatcher("ReturnABookPage.jsp").forward(request, response);
                }
            }
        }
    }
}