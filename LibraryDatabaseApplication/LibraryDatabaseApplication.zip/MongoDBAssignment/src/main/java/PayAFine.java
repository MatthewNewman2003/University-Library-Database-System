//Importing libraries
import com.mongodb.client.FindIterable;
import jakarta.ejb.EJB;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.bson.Document;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

//Declaring servlet named PayAFine
@WebServlet(name = "PayAFine", value = "/PayAFine")
public class PayAFine extends HttpServlet {
    //Declaring PayFine beans for MongoDB and Oracle
    @EJB
    MongoDBFineBean MongoDBPayFine;
    @EJB
    OracleFineBean OraclePayFine;

    //Declaring the two data sources for the Servlet
    enum DatabaseType{
        ORACLE, MONGODB;
    }

    //Setting the database type used by the servlet
    //This is set to Oracle by default, but can be changed to MongoDB
    private PayAFine.DatabaseType Database = PayAFine.DatabaseType.ORACLE;

    //Subroutine for handling GET requests (as none occur here, this is empty)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    //Subroutine for handling POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Fetching the user's session data and extracting their email address from this
        HttpSession session = request.getSession();
        Object EmailAddress = session.getAttribute("EmailAddress");

        //Fetching loan name and fine date from the request, converting email address to a string and declaring fine amount
        String LoanName = request.getParameter("LoanName");
        String EmailAddressStr = EmailAddress.toString();
        String FineDateStr = request.getParameter("FineDate");
        Integer FineAmount = 50;

        //Declaring FineDate as a null Date variable
        Date FineDate = null;
        //Trying to convert fine date string into a date
        //If it cannot be converted, a parse exception is thrown
        try {
            SimpleDateFormat DateConverter = new SimpleDateFormat("yyyy-MM-dd");
            FineDate = DateConverter.parse(FineDateStr);
        }catch(ParseException exp){
            exp.printStackTrace();
        }

        //Outcome if data source is MongoDB
        if(Database == DatabaseType.MONGODB) {
            //Finding the loan with the given name and providing the result
            FindIterable<Document> FindLoan = MongoDBPayFine.FindLoan(LoanName);
            Document Result = FindLoan.first();
            //Outcome if a loan with the given name is found
            if (Result != null) {
                //Checking if book is unreturned
                Boolean IsBookUnReturned = MongoDBPayFine.IsBookUnReturned(Result);
                //Outcome if book is unreturned
                if (IsBookUnReturned) {
                    //Informing the user that their book needs to be returned before a fine can be paid
                    String Message = "This book has not been returned yet. A fine cannot be paid until after the book has been returned.";
                    request.setAttribute("Message", Message);
                    request.getRequestDispatcher("PayAFinePage.jsp").forward(request, response);
                } else {
                    //If the book was returned, the return is checked to see if it was late
                    Boolean WasBookReturnedLate = MongoDBPayFine.WasBookReturnedLate(Result);
                    //Outcome if return was late
                    if (WasBookReturnedLate) {
                        //Checking if fine is unpaid
                        Boolean IsFineUnpaid = MongoDBPayFine.IsFineUnpaid(Result);
                        //Outcome if fine is unpaid
                        if (IsFineUnpaid) {
                            //If the fine is unpaid, the fine is inserted into the database and the loan is updated accordingly
                            MongoDBPayFine.UpdateLoan(Result);
                            Document Fine = new Document()
                                    .append("LoanName", LoanName)
                                    .append("EmailAddress", EmailAddressStr)
                                    .append("FineDate", FineDate)
                                    .append("FineAmount", FineAmount);
                            MongoDBPayFine.PayFine(Fine);
                            //Outputting a message thanking the user for paying a fine
                            String Message = "Thank you for paying the fine on this loan. You have been charged £50.";
                            request.setAttribute("Message", Message);
                            request.getRequestDispatcher("PayAFinePage.jsp").forward(request, response);
                        } else {
                            //Informing the user that the fine has already been paid, and they do not need to pay again
                            String Message = "A fine has already been paid for this loan. You do not need to pay another one.";
                            request.setAttribute("Message", Message);
                            request.getRequestDispatcher("PayAFinePage.jsp").forward(request, response);
                        }
                    } else {
                        //Informing the user that their book was returned on time and does not require a fine to be paid
                        String Message = "This book was returned on time. No fine needs to be paid.";
                        request.setAttribute("Message", Message);
                        request.getRequestDispatcher("PayAFinePage.jsp").forward(request, response);
                    }
                }
            } else {
                //Informing the user that the given loan name does not exist and encouraging them to provide a new one
                String Message = "This loan name does not exist. Please provide a loan name that does exist.";
                request.setAttribute("Message", Message);
                request.getRequestDispatcher("PayAFinePage.jsp").forward(request, response);
            }
        } else{
            //If the data source is Oracle, the FineDate is converted into an SQL date
            java.sql.Date FineDateSQL = new java.sql.Date(FineDate.getTime());

            //Declaring a new Fine class and setting the details
            Fine NewFine = new Fine();
            NewFine.setLoanName(LoanName);
            NewFine.setEmailAddress(EmailAddressStr);
            NewFine.setFineDate(FineDateSQL);
            NewFine.setFineAmount(50);

            //Finding a loan with the given name
            ArrayList<Loan> FindLoan = OraclePayFine.FindLoan(LoanName);
            //Outcome if no loan is found
            if(FindLoan.isEmpty()){
                //Informing the user that their loan name does not exist
                String Message = "This loan name does not exist. Please provide a loan name that does exist.";
                request.setAttribute("Message", Message);
                request.getRequestDispatcher("PayAFinePage.jsp").forward(request, response);
            } else{
                //If a loan is found, it is checked to see if the book is unreturned
                Boolean IsBookUnreturned = OraclePayFine.IsBookUnreturned(LoanName);
                //Outcome if the book is unreturned
                if(IsBookUnreturned){
                    //Informing the user that their book needs to be returned before a fine can be paid
                    String Message = "This book has not been returned yet. A fine cannot be paid until after the book has been returned.";
                    request.setAttribute("Message", Message);
                    request.getRequestDispatcher("PayAFinePage.jsp").forward(request, response);
                } else{
                    //If the book has been returned, the loan is checked to see if it was returned late
                    Boolean WasBookReturnedLate = OraclePayFine.WasBookReturnedLate(LoanName);
                    //Outcome if book was returned late
                    if(WasBookReturnedLate){
                        //Checking if fine is unpaid
                        Boolean IsFineUnpaid = OraclePayFine.IsFineUnpaid(LoanName);
                        //Outcome if fine is unpaid
                        if(IsFineUnpaid){
                            //Updating the loan and paying the fine
                            OraclePayFine.UpdateLoan(LoanName);
                            OraclePayFine.PayFine(NewFine);
                            //Thanking the user for paying the fine
                            String Message = "Thank you for paying the fine on this loan. You have been charged £50.";
                            request.setAttribute("Message", Message);
                            request.getRequestDispatcher("PayAFinePage.jsp").forward(request, response);
                        } else{
                            //Informing the user that a fine has already been paid, and that they do not need to pay again
                            String Message = "A fine has already been paid for this loan. You do not need to pay another one.";
                            request.setAttribute("Message", Message);
                            request.getRequestDispatcher("PayAFinePage.jsp").forward(request, response);
                        }
                    } else{
                        //Informing the user that the book was returned on time, and that no fine is required
                        String Message = "This book was returned on time. No fine needs to be paid.";
                        request.setAttribute("Message", Message);
                        request.getRequestDispatcher("PayAFinePage.jsp").forward(request, response);
                    }
                }
            }
        }
    }
}