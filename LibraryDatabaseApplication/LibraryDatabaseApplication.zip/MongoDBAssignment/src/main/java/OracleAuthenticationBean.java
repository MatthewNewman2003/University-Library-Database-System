//Importing libraries
import jakarta.ejb.EJB;
import jakarta.ejb.Stateless;
import java.sql.*;
import java.util.ArrayList;

//Declaring stateless JavaBean named OracleAuthenticationBean
@Stateless(name="OracleAuthenticationBean")
public class OracleAuthenticationBean {
    //Declaring ConnectionBean to connect to Oracle
    @EJB
    OracleConnectionBean OracleConnection;

    //Subroutine for initialising AuthenticationBean
    public OracleAuthenticationBean(){

    }

    //Subroutine for finding a student
    public ArrayList<Student> FindStudent(Student ExistingStudent){
        //Preparing SQL query for finding a student with the given credentials
        String Query = "SELECT * FROM StudentsTable WHERE EmailAddress = ? AND Password = ?";

        //Declaring an array list to contain the results
        ArrayList ResultsList = new ArrayList();
        try{
            //Connecting to Oracle
            Connection OracleConnect = OracleConnection.GetOracleConnection();
            //Preparing statement based on SQL query
            PreparedStatement SQLQuery = OracleConnect.prepareStatement(Query);
            //Setting the parameters of the prepared statement to those inputted by the user
            SQLQuery.setString(1, ExistingStudent.getEmailAddress());
            SQLQuery.setString(2, ExistingStudent.getPassword());
            //Executing query
            ResultSet Result = SQLQuery.executeQuery();

            //Appending any found students into the results list
            while(Result.next()){
                Student FoundStudent = new Student();
                FoundStudent.setEmailAddress(Result.getString("EmailAddress"));
                FoundStudent.setFirstName(Result.getString("FirstName"));
                FoundStudent.setLastName(Result.getString("LastName"));
                FoundStudent.setPassword(Result.getString("Password"));
                ResultsList.add(FoundStudent);
            }

            System.out.println("Finding existing students.");

            //Closing the SQL query
            SQLQuery.close();

            //Returning the results
            return ResultsList;
        } catch(SQLException Exception){
            //Outcome if an SQL exception occurs
            System.out.println("SQL Exception occurred.");
            Exception.printStackTrace();
        }
        //Returning the results
        return ResultsList;
    }
}
