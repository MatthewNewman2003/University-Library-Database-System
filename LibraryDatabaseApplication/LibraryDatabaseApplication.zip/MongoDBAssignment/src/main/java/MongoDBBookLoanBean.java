//Importing libraries
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import org.bson.Document;
import jakarta.ejb.Stateless;
import jakarta.ejb.EJB;
import org.bson.conversions.Bson;
import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;

//Declaring stateless bean named MongoDBBookLoanBean
@Stateless(name="MongoDBBookLoanBean")
public class MongoDBBookLoanBean {
    //Declaring ConnectionBean to facilitate MongoDB connection
    @EJB
    MongoDBConnectionBean MongoDBConnection;

    //Subroutine for initialising BookLoanBean
    public MongoDBBookLoanBean(){

    }

    //Subroutine for registering a loan
    public void RegisterLoan(Document Loan, String BookName){
        //Connecting to MongoDB
        MongoClient MongoConnection = MongoDBConnection.getMongoClient();

        //Fetching the library database
        MongoDatabase LibraryDatabase = MongoConnection.getDatabase("LibraryDatabase");

        //Fetching the loans collection
        MongoCollection<Document> LoansCollection = LibraryDatabase.getCollection("LoansCollection");

        //Inserting loan into the loans collection
        LoansCollection.insertOne(Loan);

        //Fetching the books collection
        MongoCollection<Document> BooksCollection = LibraryDatabase.getCollection("BooksCollection");

        //Declaring filter to filter the books collection to only work with the book with a given name
        Bson Query = Filters.eq("BookName", BookName);

        //Declaring update query to set a book's CurrentlyAvailable status to No
        Bson Update = Updates.set("CurrentlyAvailable", "No");

        //Running update query on the book chosen by the user
        BooksCollection.updateOne(Query, Update);
    }

    //Subroutine for finding an available book
    public FindIterable<Document> FindBook(String BookName){
        //Connecting to MongoDB
        MongoClient MongoConnection = MongoDBConnection.getMongoClient();

        //Fetching the library database
        MongoDatabase LibraryDatabase = MongoConnection.getDatabase("LibraryDatabase");

        //Fetching the books collection
        MongoCollection<Document> BooksCollection = LibraryDatabase.getCollection("BooksCollection");

        //Finding an available book with the book name given by the user within the database
        FindIterable<Document> IsBookAvailable = BooksCollection.find(and(eq("BookName",BookName), eq("CurrentlyAvailable", "Yes")));

        //Returning result
        return IsBookAvailable;
    }

    //Subroutine for finding a loan
    public FindIterable<Document> FindLoanName(String LoanName){
        //Connecting to MongoDB
        MongoClient MongoConnection = MongoDBConnection.getMongoClient();

        //Fetching the library database
        MongoDatabase LibraryDatabase = MongoConnection.getDatabase("LibraryDatabase");

        //Fetching the loans collection
        MongoCollection<Document> LoansCollection = LibraryDatabase.getCollection("LoansCollection");

        //Searching for a loan with the loan name given by the user within the database
        FindIterable<Document> IsLoanNamePresent = LoansCollection.find(eq("LoanName",LoanName));

        //Returning the result
        return IsLoanNamePresent;
    }
}
