//Importing libraries
import jakarta.ejb.EJB;
import jakarta.ejb.Stateless;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

//Declaring stateless JavaBean named OracleLoanHistoryBean
@Stateless(name="OracleLoanHistoryBean")
public class OracleLoanHistoryBean {
    //Declaring ConnectionBean to connect to Oracle
    @EJB
    OracleConnectionBean OracleConnection;

    //Subroutine for initialising the LoanHistoryBean
    public OracleLoanHistoryBean(){

    }

    //Subroutine for finding loan history
    public ArrayList<Loan> FindLoanHistory(Date Month, String EmailAddress){
        //Setting the given month as a date
        Calendar Days = Calendar.getInstance();
        Days.setTime(Month);

        //Fetching year and month from the given month
        Integer YearOfMonth = Days.get(Days.YEAR);
        Integer MonthOfMonth = Days.get(Days.MONTH) + 1;

        //Declaring SQL query to search for the loans taken out by a given student in a given month
        String Query = "SELECT * FROM LoansTable WHERE EXTRACT(YEAR FROM TO_DATE(LoanDate)) = ? AND EXTRACT(MONTH FROM TO_DATE(LoanDate)) = ? AND EmailAddress = ?";

        //Declaring array list to store the results
        ArrayList<Loan> LoanHistory = new ArrayList();

        try{
            //Connecting to Oracle
            Connection OracleConnect = OracleConnection.GetOracleConnection();
            //Preparing a statement based on the SQL query
            PreparedStatement SQLQuery = OracleConnect.prepareStatement(Query);
            //Setting the parameter values of the prepared statement
            SQLQuery.setInt(1, YearOfMonth);
            SQLQuery.setInt(2, MonthOfMonth);
            SQLQuery.setString(3, EmailAddress);
            //Executing the SQL query
            ResultSet Result = SQLQuery.executeQuery();

            //Appending each loan found into the results list
            while(Result.next()){
                Loan FoundLoan = new Loan();
                FoundLoan.setLoanName(Result.getString("LoanName"));
                FoundLoan.setEmailAddress(Result.getString("EmailAddress"));
                FoundLoan.setBookName(Result.getString("BookName"));
                FoundLoan.setLoanDate(Result.getDate("LoanDate"));
                FoundLoan.setDueDate(Result.getDate("DueDate"));
                FoundLoan.setReturnDate(Result.getDate("ReturnDate"));
                FoundLoan.setReturnedOnTime(Result.getString("ReturnedOnTime"));
                LoanHistory.add(FoundLoan);
            }

            System.out.println("Fetching loan history");

            //Closing the SQL query
            SQLQuery.close();

            //Returning the results
            return LoanHistory;
        } catch(SQLException Exception){
            //Outcome if an SQL exception is thrown
            System.out.println("SQL Exception occurred.");
            Exception.printStackTrace();
        }
        //Returning the results
        return LoanHistory;
    }
}
