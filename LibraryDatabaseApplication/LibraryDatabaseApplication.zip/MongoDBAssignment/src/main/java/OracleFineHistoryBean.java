//Importing libraries
import jakarta.ejb.EJB;
import jakarta.ejb.Stateless;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

//Declaring stateless JavaBean named OracleFineHistoryBean
@Stateless(name="OracleFineHistoryBean")
public class OracleFineHistoryBean {
    //Declaring ConnectionBean to connect to Oracle
    @EJB
    OracleConnectionBean OracleConnection;

    //Subroutine to initialise FineHistoryBean
    public OracleFineHistoryBean(){

    }

    //Subroutine for finding fine history
    public ArrayList<Fine> FindFineHistory(Date Month, String EmailAddress){
        //Setting the inputted month as a date
        Calendar Days = Calendar.getInstance();
        Days.setTime(Month);

        //Fetching the month and year of the inputted month
        Integer YearOfMonth = Days.get(Days.YEAR);
        Integer MonthOfMonth = Days.get(Days.MONTH) + 1;

        //Declaring SQL query to select the fines paid by a given student in a given month from the database
        String Query = "SELECT * FROM FinesTable WHERE EXTRACT(YEAR FROM TO_DATE(FineDate)) = ? AND EXTRACT(MONTH FROM TO_DATE(FineDate)) = ? AND EmailAddress = ?";

        //Declaring array list to store the results
        ArrayList<Fine> FineHistory = new ArrayList();

        try{
            //Connecting to Oracle
            Connection OracleConnect = OracleConnection.GetOracleConnection();
            //Preparing a statement based on the SQL query
            PreparedStatement SQLQuery = OracleConnect.prepareStatement(Query);
            //Setting the parameter values of the prepared statement
            SQLQuery.setInt(1, YearOfMonth);
            SQLQuery.setInt(2, MonthOfMonth);
            SQLQuery.setString(3, EmailAddress);
            //Executing the SQL query
            ResultSet Result = SQLQuery.executeQuery();

            //Appending each fine found into the results list
            while(Result.next()){
                Fine FoundFine = new Fine();
                FoundFine.setLoanName(Result.getString("LoanName"));
                FoundFine.setEmailAddress(Result.getString("EmailAddress"));
                FoundFine.setFineDate(Result.getDate("FineDate"));
                FoundFine.setFineAmount(Result.getInt("FineAmount"));
                FineHistory.add(FoundFine);
            }

            System.out.println("Finding fine history.");

            //Closing the SQL query
            SQLQuery.close();

            //Returning the results
            return FineHistory;
        } catch(SQLException Exception){
            //Outcome if an SQL exception was thrown
            System.out.println("SQL Exception occurred.");
            Exception.printStackTrace();
        }
        //Returning the results
        return FineHistory;
    }

    //Subroutine for calculating the total fine amount paid
    public ArrayList<FineTotal> CalculateTotalFine(Date Month, String EmailAddress){
        //Setting the month as a date
        Calendar Days = Calendar.getInstance();
        Days.setTime(Month);

        //Retreiving the year and month from the given month
        Integer YearOfMonth = Days.get(Days.YEAR);
        Integer MonthOfMonth = Days.get(Days.MONTH) + 1;

        //Declaring SQL query to calculate the total fine amount paid by a given student during a given month
        String Query = "SELECT SUM(FineAmount) as TotalFine FROM FinesTable WHERE EXTRACT(YEAR FROM TO_DATE(FineDate)) = ? AND EXTRACT(MONTH FROM TO_DATE(FineDate)) = ? AND EmailAddress = ?";

        //Declaring an array list to store the results
        ArrayList<FineTotal> TotalFine = new ArrayList();

        try{
            //Connecting to Oracle
            Connection OracleConnect = OracleConnection.GetOracleConnection();
            //Preparing a statement based on the SQL query
            PreparedStatement SQLQuery = OracleConnect.prepareStatement(Query);
            //Setting the parameter values of the prepared statement
            SQLQuery.setInt(1, YearOfMonth);
            SQLQuery.setInt(2, MonthOfMonth);
            SQLQuery.setString(3, EmailAddress);
            //Executing the SQL query
            ResultSet Result = SQLQuery.executeQuery();

            //Appending the total fine to the results list
            while(Result.next()){
                FineTotal NewFineTotal = new FineTotal();
                NewFineTotal.setTotalFine(Result.getInt("TotalFine"));
                TotalFine.add(NewFineTotal);
            }

            System.out.println("Calculating total fines paid for the month.");

            //Closing the SQL query
            SQLQuery.close();

            //Returning the result
            return TotalFine;
        } catch(SQLException Exception){
            //Outcome if an SQL exception was thrown
            System.out.println("SQL Exception occurred.");
            Exception.printStackTrace();
        }
        //Returning the result
        return TotalFine;
    }
}
