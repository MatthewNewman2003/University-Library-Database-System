//Importing libraries
import jakarta.ejb.Stateless;
import jakarta.ejb.EJB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

//Declaring stateless JavaBean named OracleBookLoanBean
@Stateless(name="OracleBookLoanBean")
public class OracleBookLoanBean {
    //Declaring ConnectionBean to connect to Oracle
    @EJB
    OracleConnectionBean OracleConnection;

    //Subroutine to initialise the BookLoanBean
    public OracleBookLoanBean(){

    }

    //Subroutine for registering a loan
    public void RegisterLoan(Loan NewLoan, String BookName){
        //Declaring SQL query to insert a loan into the database
        String LoanQuery = "INSERT INTO LoansTable (LoanName, EmailAddress, BookName, LoanDate, DueDate, ReturnDate, ReturnedOnTime, FinePaid) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try{
            //Connecting to Oracle
            Connection OracleConnect = OracleConnection.GetOracleConnection();
            //Preparing a statement using the SQL query
            PreparedStatement SQLQuery = OracleConnect.prepareStatement(LoanQuery);
            //Setting the parameters of the prepared statement to those provided by the user
            SQLQuery.setString(1, NewLoan.getLoanName());
            SQLQuery.setString(2, NewLoan.getEmailAddress());
            SQLQuery.setString(3, NewLoan.getBookName());
            SQLQuery.setDate(4, NewLoan.getLoanDate());
            SQLQuery.setDate(5, NewLoan.getDueDate());
            SQLQuery.setDate(6, null);
            SQLQuery.setString(7, null);
            SQLQuery.setString(8, null);

            //Inserting the loan into the database
            SQLQuery.executeUpdate();

            System.out.println("Loan inserted.");

            //Closing the SQL query
            SQLQuery.close();
        } catch(SQLException Exception){
            //Outcome if an SQL exception is thrown
            System.out.println("SQL Exception thrown.");
            Exception.printStackTrace();
        }

        //Declaring an SQL query to set a book's CurrentlyAvailable status to No
        String BookQuery = "UPDATE BooksTable SET CurrentlyAvailable = ? WHERE BookName = ?";
        try{
            //Connecting to Oracle
            Connection OracleConnect = OracleConnection.GetOracleConnection();
            //Preparing statement based on the SQL query
            PreparedStatement PreparedBookQuery = OracleConnect.prepareStatement(BookQuery);
            //Setting the parameter values of the prepared statement
            PreparedBookQuery.setString(1, "No");
            PreparedBookQuery.setString(2, BookName);

            //Executing the update query
            PreparedBookQuery.executeUpdate();

            System.out.println("Book updated.");

            //Closing the query
            PreparedBookQuery.close();
        } catch(SQLException Exception){
            //Outcome if an SQL exception is thrown
            System.out.println("SQL Exception thrown.");
            Exception.printStackTrace();
        }
    }

    //Subroutine for finding an available book
    public ArrayList<Book> FindBook(String BookName){
        //Declaring SQL query for finding an available book with a given name in the database
        String Query = "SELECT * FROM BooksTable WHERE BookName = ? AND CurrentlyAvailable = ?";

        //Declaring array list to store the results
        ArrayList ResultsList = new ArrayList();
        try{
            //Connecting to Oracle
            Connection OracleConnect = OracleConnection.GetOracleConnection();
            //Preparing statement based on SQL query
            PreparedStatement SQLQuery = OracleConnect.prepareStatement(Query);
            //Setting the parameter values of the prepared statement
            SQLQuery.setString(1, BookName);
            SQLQuery.setString(2, "Yes");
            //Executing the query
            ResultSet Result = SQLQuery.executeQuery();

            //Appending any books found into the results list
            while(Result.next()){
                Book MatchingBook = new Book();
                MatchingBook.setBookName(Result.getString("BookName"));
                MatchingBook.setGenre(Result.getString("Genre"));
                MatchingBook.setAuthor(Result.getString("Author"));
                MatchingBook.setCurrentlyAvailable(Result.getString("CurrentlyAvailable"));
                ResultsList.add(MatchingBook);
            }

            System.out.println("Finding existing books.");

            //Closing SQL query
            SQLQuery.close();

            //Returning the results
            return ResultsList;
        } catch(SQLException Exception){
            //Outcome if an SQL exception is thrown
            System.out.println("SQL Exception occurred.");
            Exception.printStackTrace();
        }
        //Returning the results
        return ResultsList;
    }

    //Subroutine for finding a loan
    public ArrayList<Loan> FindLoan(String LoanName){
        //Declaring SQL query for finding the loan with a given name within the database
        String Query = "SELECT * FROM LoansTable WHERE LoanName = ?";

        //Declaring results list to store the results
        ArrayList ResultsList = new ArrayList();
        try{
            //Connecting to Oracle
            Connection OracleConnect = OracleConnection.GetOracleConnection();
            //Preparing statement based on the SQL query
            PreparedStatement SQLQuery = OracleConnect.prepareStatement(Query);
            //Setting the parameter value of the prepared statement
            SQLQuery.setString(1, LoanName);
            //Executing the SQL query
            ResultSet Result = SQLQuery.executeQuery();

            //Appending any found loans into the results list
            while(Result.next()){
                Loan FoundLoan = new Loan();
                FoundLoan.setLoanName(Result.getString("LoanName"));
                FoundLoan.setEmailAddress(Result.getString("EmailAddress"));
                FoundLoan.setBookName(Result.getString("BookName"));
                FoundLoan.setLoanDate(Result.getDate("LoanDate"));
                FoundLoan.setDueDate(Result.getDate("DueDate"));
                ResultsList.add(FoundLoan);
            }

        System.out.println("Finding existing loans.");

        //Closing the SQL query
        SQLQuery.close();

        //Returning the results
        return ResultsList;
        } catch(SQLException Exception){
            //Outcome if an SQL exception is thrown
            System.out.println("SQL Exception occurred.");
            Exception.printStackTrace();
        }
        //Returning the results
        return ResultsList;
    }
}
