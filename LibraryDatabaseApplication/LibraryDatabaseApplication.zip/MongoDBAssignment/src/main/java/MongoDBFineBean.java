//Importing libraries
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import jakarta.ejb.EJB;
import jakarta.ejb.Stateless;
import org.bson.Document;
import org.bson.conversions.Bson;
import static com.mongodb.client.model.Filters.eq;

//Declaring stateless JavaBean named MongoDBFineBean
@Stateless(name="MongoDBFineBean")
public class MongoDBFineBean {
    //Declaring ConnectionBean to fetch MongoDB connection
    @EJB
    MongoDBConnectionBean MongoDBConnection;

    //Subroutine for initialising the FineBean
    public MongoDBFineBean(){

    }

    //Subroutine for finding a loan
    public FindIterable<Document> FindLoan(String LoanName){
        //Connecting to MongoDB
        MongoClient MongoConnection = MongoDBConnection.getMongoClient();

        //Fetching the library database
        MongoDatabase LibraryDatabase = MongoConnection.getDatabase("LibraryDatabase");

        //Fetching the loans collection
        MongoCollection<Document> LoansCollection = LibraryDatabase.getCollection("LoansCollection");

        //Filtering database to show only the loan with a given loan name
        Bson Query = eq("LoanName", LoanName);

        //Applying filter to search for loans with the given name
        FindIterable<Document> IsLoanPresent = LoansCollection.find(Query);

        //Returning the result
        return IsLoanPresent;
    }

    //Subroutine for checking if a book is unreturned
    public boolean IsBookUnReturned(Document Loan){
        //Fetching the given loan's ReturnedOnTime status
        String ReturnedOnTime = Loan.getString("ReturnedOnTime");

        //Checking if the ReturnedOnTime status is blank (if it is, the book is unreturned)
        Boolean IsBookUnReturned = ReturnedOnTime.isBlank();

        //Returning the result
        return IsBookUnReturned;
    }

    //Subroutine for checking if a book was returned late
    public boolean WasBookReturnedLate(Document Loan){
        //Fetching the given loan's ReturnedOnTime status
        String ReturnedOnTime = Loan.getString("ReturnedOnTime");

        //Checking if the ReturnedOnTime status is equal to No (if it is, the book was returned late)
        Boolean WasBookReturnedLate = ReturnedOnTime.equals("No");

        //Returning the result
        return WasBookReturnedLate;
    }

    //Subroutine for checking if a required fine has been paid
    public boolean IsFineUnpaid(Document Loan){
        //Fetching the given loan's FinePaid status
        String FinePaid = Loan.getString("FinePaid");

        //Checking if the FinePaid status is equal to No (if it is, the required fine has not been paid)
        Boolean IsFineUnpaid = FinePaid.equals("No");

        //Returning the result
        return IsFineUnpaid;
    }

    //Subroutine for updating a loan
    public void UpdateLoan(Document Loan){
        //Fetching the LoanName given by the user
        String LoanName = Loan.getString("LoanName");

        //Connecting to MongoDB
        MongoClient MongoConnection = MongoDBConnection.getMongoClient();

        //Fetching the library database
        MongoDatabase LibraryDatabase = MongoConnection.getDatabase("LibraryDatabase");

        //Fetching the loans collection
        MongoCollection<Document> LoansCollection = LibraryDatabase.getCollection("LoansCollection");

        //Filtering the database to only show the loan with a given name
        Bson Query = Filters.eq("LoanName", LoanName);

        //Declaring query to update a loan's FinePaid status to Yes
        Bson UpdatedValues = Updates.set("FinePaid", "Yes");

        //Applying the update query to the loan with the given name
        LoansCollection.updateOne(Query, UpdatedValues);
    }

    //Subroutine for paying a fine
    public void PayFine(Document Fine){
        //Connecting to MongoDB
        MongoClient MongoConnection = MongoDBConnection.getMongoClient();

        //Fetching the library database
        MongoDatabase LibraryDatabase = MongoConnection.getDatabase("LibraryDatabase");

        //Fetching the fines collection
        MongoCollection<Document> FinesCollection = LibraryDatabase.getCollection("FinesCollection");

        //Inserting the fine into the database
        FinesCollection.insertOne(Fine);
    }
}
