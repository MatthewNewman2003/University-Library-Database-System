//Importing libraries
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.MongoCursor;
import jakarta.ejb.EJB;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.bson.Document;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

//Declaring servlet named LoanHistory
@WebServlet(name = "LoanHistory", value = "/LoanHistory")
public class LoanHistory extends HttpServlet {
    //Declaring LoanHistoryBeans for MongoDB and Oracle
    @EJB
    MongoDBLoanHistoryBean MongoDBLoanHistory;
    @EJB
    OracleLoanHistoryBean OracleLoanHistory;

    //Declaring the two database types for the servlet
    enum DatabaseType{
        ORACLE, MONGODB;
    }

    //Setting database type for the Servlet
    //This is set to Oracle by default, but can be changed to MongoDB
    private LoanHistory.DatabaseType Database = LoanHistory.DatabaseType.ORACLE;

    //Subroutine for handling GET requests (as none are sent here, this is empty)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    //Subroutine for handling POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Fetching the user's session data and extracting their email address from this
        HttpSession session = request.getSession();
        Object EmailAddress = session.getAttribute("EmailAddress");

        //Converting email address to a string and fetching month from the request
        String EmailAddressStr = EmailAddress.toString();
        String MonthStr = request.getParameter("Month");

        //Declaring a null date variable to represent the month
        Date Month = null;
        //Trying to convert the inputted month string into a date
        //If the string cannot be converted to a date, a parse exception is thrown
        try {
            SimpleDateFormat DateConverter = new SimpleDateFormat("yyyy-MM");
            Month = DateConverter.parse(MonthStr);
        }catch(ParseException exp){
            exp.printStackTrace();
        }

        //Outcome if the database type is MongoDB
        if(Database == DatabaseType.MONGODB){
            //Finding loan history for the given username and month and providing the result
            AggregateIterable<Document> FindLoanHistory = MongoDBLoanHistory.FindLoanHistory(Month, EmailAddressStr);
            Document AnyLoanHistory = FindLoanHistory.first();
            //Outcome if loan history is found
            if(AnyLoanHistory != null){
                //Iterating through the loans and outputting each loan onto the page
                MongoCursor<Document> Cursor = FindLoanHistory.iterator();
                String Message = "<h2>You took out the following loans during the inputted month: </h2>";
                try{
                    while(Cursor.hasNext()){
                        Document Loan = Cursor.next();

                        Message = Message + "<br>"
                                + "Loan Name: " + Loan.get("LoanName") + "<br>"
                                + "Book Name: " + Loan.get("BookName") + "<br>"
                                + "Loan Date: " + Loan.get("LoanDate") + "<br>"
                                + "Due Date: " + Loan.get("DueDate") + "<br>"
                                + "Return Date: " + Loan.get("ReturnDate") + "<br>"
                                + "Returned on Time?: " + Loan.get("ReturnedOnTime") + "<br>"
                                + "<hr>";
                    }
                }finally{
                    Cursor.close();
                }
                request.setAttribute("Message", Message);
                request.getRequestDispatcher("LoanHistoryPage.jsp").forward(request, response);
            } else{
                //If no loan history is found, the user is informed of this and encouraged to try a different month
                String Message = "You did not take out any loans during this month. Please try a different month.";
                request.setAttribute("Message", Message);
                request.getRequestDispatcher("LoanHistoryPage.jsp").forward(request, response);
            }
        } else{
            //If the database type is Oracle, the database is searched for loan history matching the given month and email address
            ArrayList<Loan> LoanHistory = OracleLoanHistory.FindLoanHistory(Month, EmailAddressStr);
            //Outcome if no loan history is found
            if(LoanHistory.isEmpty()){
                //If no loan history is found, the user is informed of this and encouraged to pick a different month
                String Message = "You did not take out any loans during this month. Please try a different month.";
                request.setAttribute("Message", Message);
                request.getRequestDispatcher("LoanHistoryPage.jsp").forward(request, response);
            } else{
                //If loan history is found, the array of loans is iterated through and each loan is outputted on the page
                Iterator<Loan> Cursor = LoanHistory.iterator();
                String Message = "<h2>You took out the following loans during the inputted month: </h2>";
                while(Cursor.hasNext()){
                    Loan FoundLoan = new Loan();
                    FoundLoan = (Loan)Cursor.next();


                    Message = Message + "<br>"
                            + "Loan Name: " + FoundLoan.getLoanName() + "<br>"
                            + "Book Name: " + FoundLoan.getBookName() + "<br>"
                            + "Loan Date: " + FoundLoan.getLoanDate() + "<br>"
                            + "Due Date: " + FoundLoan.getDueDate() + "<br>"
                            + "Return Date: " + FoundLoan.getReturnDate() + "<br>"
                            + "Returned on Time?: " + FoundLoan.getReturnedOnTime() + "<br>"
                            + "<hr>";
                }
                request.setAttribute("Message", Message);
                request.getRequestDispatcher("LoanHistoryPage.jsp").forward(request, response);
            }
        }


    }
}