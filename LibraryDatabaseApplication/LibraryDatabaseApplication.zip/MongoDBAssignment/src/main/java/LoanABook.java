//Importing libraries
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import jakarta.ejb.EJB;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import com.mongodb.client.*;
import org.bson.Document;

//Declaring servlet named LoanABook
@WebServlet(name = "LoanABook", value = "/LoanABook")
public class LoanABook extends HttpServlet {
    //Declaring BookLoanBeans for MongoDB and Oracle
    @EJB
    MongoDBBookLoanBean MongoDBBookLoan;
    @EJB
    OracleBookLoanBean OracleBookLoan;

    //Declaring the two database types for the servlet
    enum DatabaseType{
        ORACLE, MONGODB;
    }

    //Setting the database type for the servlet
    //This is set to Oracle by default, but can be changed to MongoDB
    private LoanABook.DatabaseType Database = LoanABook.DatabaseType.ORACLE;

    //Subroutine for handling GET requests (this is empty, as no GET requests are sent)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    //Subroutine for handling POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Setting response type to HTML text
        response.setContentType("text/html");

        //Fetching the user's session data and extracting their email address from it
        HttpSession session = request.getSession();
        Object EmailAddress = session.getAttribute("EmailAddress");

        //Getting form parameters and converting email address to a string
        String LoanName = request.getParameter("LoanName");
        String EmailAddressStr = EmailAddress.toString();
        String BookName = request.getParameter("BookName");
        String LoanDateStr = request.getParameter("LoanDate");

        //Declaring a null date variable to represent the LoanDate
        Date LoanDate = null;

        //Trying to convert the given date string into a date
        //If the string cannot be converted into a date, a ParseException is thrown
        try {
            SimpleDateFormat DateConverter = new SimpleDateFormat("yyyy-MM-dd");
            LoanDate = DateConverter.parse(LoanDateStr);
        } catch (ParseException exp) {
            exp.printStackTrace();
        }

        //Setting DueDate 2 weeks after the LoanDate
        Calendar Days = Calendar.getInstance();
        Days.setTime(LoanDate);
        Days.add(Days.DAY_OF_YEAR, 14);
        Date DueDate = Days.getTime();

        //Outcome if DatabaseType is MongoDB
        if(Database == DatabaseType.MONGODB){
            //Finding an available book with the given name and providing the result
            FindIterable<Document> FindBook = MongoDBBookLoan.FindBook(BookName);
            Document BookResult = FindBook.first();

            //Outcome if an available book with the given name is found
            if (BookResult != null) {
                //Finding a loan with the given name and providing the result
                FindIterable<Document> FindLoanName = MongoDBBookLoan.FindLoanName(LoanName);
                Document LoanNameResult = FindLoanName.first();
                //Outcome if a loan with the given name is found
                if (LoanNameResult != null) {
                    //Informing the user that a loan with this name already exists and encouraging them to pick a new name
                    String Message = "A loan of this name already exists. Please pick a new name.";
                    request.setAttribute("Message", Message);
                    request.getRequestDispatcher("LoanABookPage.jsp").forward(request, response);
                } else {
                    //If a loan with the given name does not exist, the loan is appended into the database
                    Document Loan = new Document()
                            .append("EmailAddress", EmailAddressStr)
                            .append("LoanName", LoanName)
                            .append("BookName", BookName)
                            .append("LoanDate", LoanDate)
                            .append("DueDate", DueDate)
                            .append("ReturnDate", "")
                            .append("ReturnedOnTime", "")
                            .append("FinePaid", "");

                    MongoDBBookLoan.RegisterLoan(Loan, BookName);

                    //Informing the user of their successfully added loan and the 2 weeks they have to return the book
                    String Message = "Loan successfully added. You have 2 weeks to return this book.";
                    request.setAttribute("Message", Message);
                    request.getRequestDispatcher("LoanABookPage.jsp").forward(request, response);
                }
            } else {
                //If no available book with the given BookName is found, the user is informed of this and encouraged to input an available book
                String Message = "This is not an available book within the database. Please input a book that is available.";
                request.setAttribute("Message", Message);
                request.getRequestDispatcher("LoanABookPage.jsp").forward(request, response);
            }
        } else{
            //If the database type is Oracle, the LoanDate and DueDate are set to SQL dates so that they can be interpreted correctly by the database
            java.sql.Date LoanDateSQL = new java.sql.Date(LoanDate.getTime());
            java.sql.Date DueDateSQL = new java.sql.Date(DueDate.getTime());

            //Finding an available book with the given name within the database
            ArrayList<Book> BookResult = OracleBookLoan.FindBook(BookName);
            //Outcome if no available book with the given name is found
            if(BookResult.isEmpty()){
                //Informing the user that no available book was found and encouraging them to input a new book name
                String Message = "This is not an available book within the database. Please input a book that is available.";
                request.setAttribute("Message", Message);
                request.getRequestDispatcher("LoanABookPage.jsp").forward(request, response);
            } else{
                //If an available book was found, the database is searched for loans with the given loan name
                ArrayList<Loan> LoanNameResult = OracleBookLoan.FindLoan(LoanName);
                //Outcome if no loans with a matching name are found
                if(LoanNameResult.isEmpty()){
                    //Declaring a new loan and setting its details
                    Loan NewLoan = new Loan();
                    NewLoan.setLoanName(LoanName);
                    NewLoan.setEmailAddress(EmailAddressStr);
                    NewLoan.setBookName(BookName);
                    NewLoan.setLoanDate(LoanDateSQL);
                    NewLoan.setDueDate(DueDateSQL);

                    //Adding the loan to the database
                    OracleBookLoan.RegisterLoan(NewLoan, BookName);

                    //Informing the user of their successful loan addition and the 2 weeks they have to return the book
                    String Message = "Loan successfully added. You have 2 weeks to return this book.";
                    request.setAttribute("Message", Message);
                    request.getRequestDispatcher("LoanABookPage.jsp").forward(request, response);
                } else{
                    //If a loan with the given name is found, the user is informed that a loan with this name already exists and is encouraged to pick a new name
                    String Message = "A loan of this name already exists. Please pick a new name.";
                    request.setAttribute("Message", Message);
                    request.getRequestDispatcher("LoanABookPage.jsp").forward(request, response);
                }
            }
        }
    }
}