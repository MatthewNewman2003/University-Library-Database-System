//Importing Serializable library
import java.io.Serializable;

//Declaring Student class
public class Student implements Serializable {
    //Declaring private variables EmailAddress, FirstName, LastName and Password
    private String EmailAddress;
    private String FirstName;
    private String LastName;
    private String Password;

    //Subroutine for getting email address
    public String getEmailAddress(){
        return EmailAddress;
    }

    //Subroutine for setting email address
    public void setEmailAddress(String Email){
        this.EmailAddress = Email;
    }

    //Subroutine for getting first name
    public String getFirstName(){
        return FirstName;
    }

    //Subroutine for setting first name
    public void setFirstName(String FirstName){
        this.FirstName = FirstName;
    }

    //Subroutine for getting last name
    public String getLastName(){
        return LastName;
    }

    //Subroutine for setting last name
    public void setLastName(String LastName){
        this.LastName = LastName;
    }

    //Subroutine for getting password
    public String getPassword(){
        return Password;
    }

    //Subroutine for setting password
    public void setPassword(String Password){
        this.Password = Password;
    }
}
