//Importing libraries
import jakarta.ejb.EJB;
import jakarta.ejb.Stateless;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

//Declaring stateless JavaBean named OracleFineBean
@Stateless(name="OracleFineBean")
public class OracleFineBean {
    //Declaring ConnectionBean to connect to Oracle
    @EJB
    OracleConnectionBean OracleConnection;

    //Subroutine for initialising the FineBean
    public OracleFineBean(){

    }

    //Subroutine for finding a loan
    public ArrayList<Loan> FindLoan(String LoanName){
        //Declaring SQL query to find the loan with a given name
        String Query = "SELECT * FROM LoansTable WHERE LoanName = ?";

        //Declaring array list to store the results
        ArrayList ResultsList = new ArrayList();
        try{
            //Connecting to Oracle
            Connection OracleConnect = OracleConnection.GetOracleConnection();
            //Preparing a statement based on the SQL query
            PreparedStatement SQLQuery = OracleConnect.prepareStatement(Query);
            //Setting parameter value for prepared statement
            SQLQuery.setString(1, LoanName);
            //Executing SQL query
            ResultSet Result = SQLQuery.executeQuery();

            //Appending each loan found into the results list
            while(Result.next()){
                Loan FoundLoan = new Loan();
                FoundLoan.setLoanName(Result.getString("LoanName"));
                FoundLoan.setEmailAddress(Result.getString("EmailAddress"));
                FoundLoan.setBookName(Result.getString("BookName"));
                FoundLoan.setLoanDate(Result.getDate("LoanDate"));
                FoundLoan.setDueDate(Result.getDate("DueDate"));
                FoundLoan.setReturnDate(Result.getDate("ReturnDate"));
                FoundLoan.setReturnedOnTime(Result.getString("ReturnedOnTime"));
                FoundLoan.setFinePaid(Result.getString("FinePaid"));
                ResultsList.add(FoundLoan);
            }

            System.out.println("Finding existing loans.");

            //Closing the SQL query
            SQLQuery.close();

            //Returning the results
            return ResultsList;
        } catch(SQLException Exception){
            //Outcome if an SQL exception is thrown
            System.out.println("SQL Exception occurred.");
            Exception.printStackTrace();
        }
        //Returning the results
        return ResultsList;
    }

    //Subroutine for checking if a book is unreturned
    public boolean IsBookUnreturned(String LoanName){
        //Declaring SQL query to search the database for loans of a given name with a non-null return date
        String Query = "SELECT * FROM LoansTable WHERE LoanName=? and ReturnDate IS NOT NULL";

        //Declaring an array list to store the results
        ArrayList<Loan> MatchingLoans = new ArrayList();
        try{
            //Connecting to Oracle
            Connection OracleConnect = OracleConnection.GetOracleConnection();
            //Preparing a statement based on the SQL query
            PreparedStatement SQLQuery = OracleConnect.prepareStatement(Query);
            //Setting the parameter value of the prepared statement
            SQLQuery.setString(1,LoanName);
            //Executing the SQL query
            ResultSet Result = SQLQuery.executeQuery();

            //Appending each loan found to the results list
            while(Result.next()){
                Loan FoundLoan = new Loan();
                FoundLoan.setLoanName(Result.getString("LoanName"));
                FoundLoan.setEmailAddress(Result.getString("EmailAddress"));
                FoundLoan.setBookName(Result.getString("BookName"));
                FoundLoan.setLoanDate(Result.getDate("LoanDate"));
                FoundLoan.setDueDate(Result.getDate("DueDate"));
                MatchingLoans.add(FoundLoan);
            }

            System.out.println("Checking if book has been returned.");

            //Closing the SQL query
            SQLQuery.close();
        } catch(SQLException Exception){
            //Outcome if an SQL exception is thrown
            System.out.println("SQL Exception occurred.");
            Exception.printStackTrace();
        }

        //Checking if the list of matching loans is empty (if it is, the book is unreturned)
        Boolean IsBookUnreturned = MatchingLoans.isEmpty();

        //Returning the results
        return IsBookUnreturned;
    }

    //Subroutine for checking whether a book was returned late
    public boolean WasBookReturnedLate(String LoanName){
        //Declaring SQL query to search for a loan with a given name and ReturnedOnTime status
        String Query = "SELECT * FROM LoansTable WHERE LoanName=? and ReturnedOnTime=?";

        //Declaring array list to store the results
        ArrayList<Loan> MatchingLoans = new ArrayList();
        try{
            //Connecting to Oracle
            Connection OracleConnect = OracleConnection.GetOracleConnection();
            //Preparing a statement based on the SQL query
            PreparedStatement SQLQuery = OracleConnect.prepareStatement(Query);
            //Setting parameter values of the prepared statement
            SQLQuery.setString(1,LoanName);
            SQLQuery.setString(2,"Yes");
            //Executing the SQL query
            ResultSet Result = SQLQuery.executeQuery();

            //Appending each loan found into the results list
            while(Result.next()){
                Loan FoundLoan = new Loan();
                FoundLoan.setLoanName(Result.getString("LoanName"));
                FoundLoan.setEmailAddress(Result.getString("EmailAddress"));
                FoundLoan.setBookName(Result.getString("BookName"));
                FoundLoan.setLoanDate(Result.getDate("LoanDate"));
                FoundLoan.setDueDate(Result.getDate("DueDate"));
                FoundLoan.setReturnDate(Result.getDate("ReturnDate"));
                FoundLoan.setReturnedOnTime(Result.getString("ReturnedOnTime"));
                MatchingLoans.add(FoundLoan);
            }

            System.out.println("Checking if book was returned on time.");

            //Closing the SQL query
            SQLQuery.close();
        } catch(SQLException Exception){
            //Outcome if an SQL exception was thrown
            System.out.println("SQL Exception occurred.");
            Exception.printStackTrace();
        }

        //Checking whether matching loans list is empty (If it is, the book was returned late)
        Boolean WasBookReturnedOnTime = MatchingLoans.isEmpty();

        //Returning the results
        return WasBookReturnedOnTime;
    }

    //Subroutine for checking whether a fine is unpaid
    public boolean IsFineUnpaid(String LoanName){
        //Declaring SQL query to search for the loan with a given name and FinePaid status
        String Query = "SELECT * FROM LoansTable WHERE LoanName=? and FinePaid=?";

        //Declaring array list to store the results
        ArrayList<Loan> MatchingLoans = new ArrayList();
        try{
            //Connecting to Oracle
            Connection OracleConnect = OracleConnection.GetOracleConnection();
            //Preparing a statement based on the SQL query
            PreparedStatement SQLQuery = OracleConnect.prepareStatement(Query);
            //Setting the parameter values of the prepared statement
            SQLQuery.setString(1,LoanName);
            SQLQuery.setString(2,"Yes");
            //Executing the SQL query
            ResultSet Result = SQLQuery.executeQuery();

            //Appending each loan found into the results list
            while(Result.next()){
                Loan FoundLoan = new Loan();
                FoundLoan.setLoanName(Result.getString("LoanName"));
                FoundLoan.setEmailAddress(Result.getString("EmailAddress"));
                FoundLoan.setBookName(Result.getString("BookName"));
                FoundLoan.setLoanDate(Result.getDate("LoanDate"));
                FoundLoan.setDueDate(Result.getDate("DueDate"));
                MatchingLoans.add(FoundLoan);
            }

            System.out.println("Checking if book has been returned.");

            //Closing the SQL query
            SQLQuery.close();
        } catch(SQLException Exception){
            //Outcome if an SQL exception was thrown
            System.out.println("SQL Exception occurred.");
            Exception.printStackTrace();
        }

        //Checking whether the matching loans list is empty (if it is, the fine is unpaid)
        Boolean HasFineBeenPaid = MatchingLoans.isEmpty();

        //Returning the results
        return HasFineBeenPaid;
    }

    //Subroutine for updating a loan
    public void UpdateLoan(String LoanName){
        //Declaring SQL query for updating the FinePaid status of the loan with a given name
        String Query = "UPDATE LoansTable SET FinePaid=? WHERE LoanName=?";
        try{
            //Connecting to Oracle
            Connection OracleConnect = OracleConnection.GetOracleConnection();
            //Preparing a statement based on the SQL query
            PreparedStatement SQLQuery = OracleConnect.prepareStatement(Query);
            //Setting the parameter values of the prepared statement
            SQLQuery.setString(1,"Yes");
            SQLQuery.setString(2,LoanName);

            //Executing the SQL query
            SQLQuery.executeUpdate();

            System.out.println("Updating loan.");

            //Closing the SQL query
            SQLQuery.close();
        } catch(SQLException Exception){
            //Outcome if an SQL exception is thrown
            System.out.println("SQL Exception occurred.");
            Exception.printStackTrace();
        }
    }

    //Subroutine for inserting a fine into the database
    public void PayFine(Fine NewFine){
        //Declaring SQL query to insert a fine into the database
        String Query = "INSERT INTO FinesTable (LoanName, EmailAddress, FineDate, FineAmount) VALUES (?, ?, ?, ?)";
        try{
            //Connecting to Oracle
            Connection OracleConnect = OracleConnection.GetOracleConnection();
            //Preparing a statement based on the SQL query
            PreparedStatement SQLQuery = OracleConnect.prepareStatement(Query);
            //Setting the parameter values of the prepared statement
            SQLQuery.setString(1, NewFine.getLoanName());
            SQLQuery.setString(2, NewFine.getEmailAddress());
            SQLQuery.setDate(3, NewFine.getFineDate());
            SQLQuery.setInt(4, NewFine.getFineAmount());

            //Executing SQL query
            SQLQuery.executeUpdate();

            System.out.println("Paying fine");

            //Closing the SQL query
            SQLQuery.close();
        } catch(SQLException Exception){
            //Outcome if an SQL exception is thrown
            System.out.println("SQL Exception occurred");
            Exception.printStackTrace();
        }
    }
}
