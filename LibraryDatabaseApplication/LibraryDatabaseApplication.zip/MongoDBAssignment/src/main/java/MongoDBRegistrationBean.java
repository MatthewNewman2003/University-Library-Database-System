//Importing libraries
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import jakarta.ejb.Stateless;
import jakarta.ejb.EJB;
import static com.mongodb.client.model.Filters.eq;

//Declaring stateless JavaBean named MongoDBRegistrationBean
@Stateless(name = "MongoDBRegistrationBean")
public class MongoDBRegistrationBean {
    //Declaring ConnectionBean to connect to MongoDB
    @EJB
    MongoDBConnectionBean MongoDBConnection;

    //Subroutine to initialise RegistrationBean
    public MongoDBRegistrationBean(){

    }

    //Subroutine for registering a student
    public void RegisterStudent(Document Student){
        //Connecting to MongoDB
        MongoClient MongoConnection = MongoDBConnection.getMongoClient();

        //Fetching the library database
        MongoDatabase LibraryDatabase = MongoConnection.getDatabase("LibraryDatabase");

        //Fetching the students collection
        MongoCollection<Document> StudentCollection = LibraryDatabase.getCollection("StudentsCollection");

        //Inserting the student into the database
        StudentCollection.insertOne(Student);
    }

    //Subroutine for finding a student
    public FindIterable<Document> FindStudent(String EmailAddress){
        //Connecting to MongoDB
        MongoClient MongoConnection = MongoDBConnection.getMongoClient();

        //Fetching the library database
        MongoDatabase LibraryDatabase = MongoConnection.getDatabase("LibraryDatabase");

        //Fetching the students collection
        MongoCollection<Document> StudentCollection = LibraryDatabase.getCollection("StudentsCollection");

        //Finding a student with the given email address
        FindIterable<Document> IsStudentPresent = StudentCollection.find(eq("EmailAddress",EmailAddress));

        //Returning the result
        return IsStudentPresent;
    }
}
