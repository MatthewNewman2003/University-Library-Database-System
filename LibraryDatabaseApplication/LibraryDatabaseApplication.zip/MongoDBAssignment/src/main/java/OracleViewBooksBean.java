//Importing libraries
import jakarta.ejb.EJB;
import jakarta.ejb.Stateless;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

//Declaring stateless JavaBean named OracleViewBooksBean
@Stateless(name="OracleViewBooksBean")
public class OracleViewBooksBean {
    //Declaring ConnectionBean to connect to Oracle
    @EJB
    OracleConnectionBean OracleConnection;

    //Subroutine for initialising the ViewBooksBean
    public OracleViewBooksBean() {

    }

    //Subroutine for finding books
    public ArrayList<Book> FindBooks(){
        //Declaring SQL query to search for books
        String Query = "SELECT * FROM BooksTable";

        //Declaring array list to store the results
        ArrayList<Book> Books = new ArrayList();

        try{
            //Connecting to Oracle
            Connection OracleConnect = OracleConnection.GetOracleConnection();
            //Preparing a statement based on the SQL query
            PreparedStatement SQLQuery = OracleConnect.prepareStatement(Query);
            //Executing the SQL query
            ResultSet Result = SQLQuery.executeQuery();

            //Appending each book found into the results list
            while(Result.next()){
                Book FoundBook = new Book();
                FoundBook.setBookName(Result.getString("BookName"));
                FoundBook.setGenre(Result.getString("Genre"));
                FoundBook.setAuthor(Result.getString("Author"));
                FoundBook.setCurrentlyAvailable(Result.getString("CurrentlyAvailable"));
                Books.add(FoundBook);
            }

            System.out.println("Fetching books");

            //Closing the SQL query
            SQLQuery.close();

            //Returning the results
            return Books;
        } catch(SQLException Exception){
            //Outcome if an SQL exception is thrown
            System.out.println("SQL Exception occurred.");
            Exception.printStackTrace();
        }
        //Returning the results
        return Books;
    }
}
