//Importing libraries
import com.mongodb.MongoClient;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Accumulators;
import com.mongodb.client.model.Filters;
import jakarta.ejb.EJB;
import jakarta.ejb.Stateless;
import org.bson.Document;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import static com.mongodb.client.model.Aggregates.*;

//Declaring stateless JavaBean called MongoDBFineHistoryBean
@Stateless(name="MongoDBFineHistoryBean")
public class MongoDBFineHistoryBean {
    //Declaring ConnectionBean to connect to MongoDB
    @EJB
    MongoDBConnectionBean MongoDBConnection;

    //Subroutine for initialising FineHistoryBean
    public MongoDBFineHistoryBean(){

    }

    //Subroutine for finding fine history
    public AggregateIterable<Document> FindFineHistory(Date Month, String EmailAddress){
        //Connecting to MongoDB
        MongoClient MongoConnection = MongoDBConnection.getMongoClient();

        //Fetching the library database
        MongoDatabase LibraryDatabase = MongoConnection.getDatabase("LibraryDatabase");

        //Fetching the fines collection
        MongoCollection<Document> FinesCollection = LibraryDatabase.getCollection("FinesCollection");

        //Setting the given month as a date
        Calendar Days = Calendar.getInstance();
        Days.setTime(Month);

        //Fetching the year and month of the given month
        Integer YearOfMonth = Days.get(Days.YEAR);
        Integer MonthOfMonth = Days.get(Days.MONTH) + 1;

        //Constructing an aggregate pipeline to find the user's fine history in a given month
        AggregateIterable<Document> FineHistory = FinesCollection.aggregate(Arrays.asList(
                new Document("$project", new Document("LoanName", 1)
                        .append("EmailAddress", 1)
                        .append("FineDate", 1)
                        .append("FineAmount", 1)
                        .append("Month", new Document("$month", "$FineDate"))
                        .append("Year", new Document("$year", "$FineDate"))),
                new Document("$match", Filters.and(Filters.eq("EmailAddress", EmailAddress),
                        Filters.eq("Month", MonthOfMonth),
                        Filters.eq("Year", YearOfMonth)))
        ));

        //Returning the result
        return FineHistory;
    }

    //Subroutine for calculating the total fine paid
    public AggregateIterable<Document> CalculateTotalFine(Date Month, String EmailAddress){
        //Connecting to MongoDB
        MongoClient MongoConnection = MongoDBConnection.getMongoClient();

        //Fetching the library database
        MongoDatabase LibraryDatabase = MongoConnection.getDatabase("LibraryDatabase");

        //Fetching the fines collection
        MongoCollection<Document> FinesCollection = LibraryDatabase.getCollection("FinesCollection");

        //Setting the month as a date
        Calendar Days = Calendar.getInstance();
        Days.setTime(Month);

        //Fetching the year and month of the given month
        Integer YearOfMonth = Days.get(Days.YEAR);
        Integer MonthOfMonth = Days.get(Days.MONTH) + 1;

        //Constructing aggregate pipeline to calculate the total fine amount paid by the user in a given month
        AggregateIterable<Document> TotalFine = FinesCollection.aggregate(Arrays.asList(
                new Document("$project", new Document("LoanName", 1)
                        .append("EmailAddress", 1)
                        .append("FineDate", 1)
                        .append("FineAmount", 1)
                        .append("Month", new Document("$month", "$FineDate"))
                        .append("Year", new Document("$year", "$FineDate"))),
                new Document("$match", Filters.and(Filters.eq("EmailAddress", EmailAddress),
                        Filters.eq("Month", MonthOfMonth),
                        Filters.eq("Year", YearOfMonth))),
                group(null, Accumulators.sum("TotalFine", "$FineAmount"))
        ));

        //Returning the result
        return TotalFine;
    }
}
