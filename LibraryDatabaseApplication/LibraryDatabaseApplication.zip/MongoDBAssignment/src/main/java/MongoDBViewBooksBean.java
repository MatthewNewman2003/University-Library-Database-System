//Importing libraries
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import jakarta.ejb.EJB;
import jakarta.ejb.Stateless;
import org.bson.Document;

//Declaring stateless JavaBean named MongoDBViewBooksBean
@Stateless(name="MongoDBViewBooksBean")
public class MongoDBViewBooksBean {
    //Declaring ConnectionBean to connect to MongoDB
    @EJB
    MongoDBConnectionBean MongoDBConnection;

    //Subroutine for initialising ViewBooksBean
    public MongoDBViewBooksBean() {

    }

    //Subroutine for finding books
    public FindIterable<Document> FindBooks() {
        //Connecting to MongoDB
        MongoClient MongoConnection = MongoDBConnection.getMongoClient();

        //Fetching the library database
        MongoDatabase LibraryDatabase = MongoConnection.getDatabase("LibraryDatabase");

        //Fetching the books collection
        MongoCollection<Document> BooksCollection = LibraryDatabase.getCollection("BooksCollection");

        //Searching for books
        FindIterable<Document> Books = BooksCollection.find();

        //Returning the results
        return Books;
    }
}