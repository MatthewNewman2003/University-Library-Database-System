//Importing libraries
import jakarta.ejb.EJB;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.util.ArrayList;
import com.mongodb.client.*;
import org.bson.Document;

//Declaring servlet named Registration
@WebServlet(name = "Registration", value = "/Registration")
public class Registration extends HttpServlet {
    //Declaring RegistrationBeans for MongoDB and Oracle
    @EJB
    MongoDBRegistrationBean MongoDBStudentRegistration;
    @EJB
    OracleRegistrationBean OracleStudentRegistration;

    //Declaring the two data sources for the servlet
    enum DatabaseType{
        ORACLE, MONGODB;
    }

    //Setting the data source used by the servlet
    //This is set to Oracle by default, but can be changed to MongoDB
    private DatabaseType Database = DatabaseType.ORACLE;

    //Subroutine for handling GET requests (as there are none here, this is empty)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    //Subroutine for handling POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Setting response type as HTML text
        response.setContentType("text/html");

        //Fetching the inputted credentials from the request
        String EmailAddress = request.getParameter("EmailAddress");
        String FirstName = request.getParameter("FirstName");
        String LastName = request.getParameter("LastName");
        String Password = request.getParameter("Password");

        //Outcome if the data source is MongoDB
        if(Database == DatabaseType.MONGODB) {
            //Finding a student with the given email address and providing the result
            FindIterable<Document> FindStudent = MongoDBStudentRegistration.FindStudent(EmailAddress);
            Document Result = FindStudent.first();
            //Outcome if a student is found
            if (Result != null) {
                //Informing the user that the inputted email address is already in use and encouraging them to input another
                String Message = "This email address has already been used. Please use another.";
                request.setAttribute("Message", Message);
                request.getRequestDispatcher("RegistrationPage.jsp").forward(request, response);
            } else {
                //If no student is found, the student's details are inputted into the database
                Document Student = new Document()
                        .append("EmailAddress", EmailAddress)
                        .append("FirstName", FirstName)
                        .append("LastName", LastName)
                        .append("Password", Password);

                MongoDBStudentRegistration.RegisterStudent(Student);

                //Setting email address as a request attribute and forwarding the user to the login page
                request.setAttribute("EmailAddress", EmailAddress);
                RequestDispatcher Dispatcher = getServletContext().getRequestDispatcher("/LoginPage.jsp");
                Dispatcher.forward(request, response);
            }
        } else{
            //If the data source is Oracle, a new Student class is created and details are set
            Student NewStudent = new Student();

            NewStudent.setEmailAddress(EmailAddress);
            NewStudent.setFirstName(FirstName);
            NewStudent.setLastName(LastName);
            NewStudent.setPassword(Password);

            //Searching the database for a student with the inputted email address
            ArrayList<Student> ExistingStudent = OracleStudentRegistration.FindStudent(NewStudent);
            //Outcome if no matching student is found
            if(ExistingStudent.isEmpty()){
                System.out.println("Registering student.");

                //Registering student
                OracleStudentRegistration.RegisterStudent(NewStudent);

                //Setting the email address as a request attribute and forwarding the user to the login page
                request.setAttribute("EmailAddress", EmailAddress);
                RequestDispatcher Dispatcher = getServletContext().getRequestDispatcher("/LoginPage.jsp");
                Dispatcher.forward(request, response);
            } else{
                //Informing the user that their inputted email address has already been used and encouraging them to try another
                String Message = "This email address has already been used. Please use another.";
                request.setAttribute("Message", Message);
                request.getRequestDispatcher("RegistrationPage.jsp").forward(request, response);
            }
        }
    }
}