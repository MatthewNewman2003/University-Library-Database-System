//Importing libraries
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import org.bson.Document;
import jakarta.ejb.Stateless;
import jakarta.ejb.EJB;
import org.bson.conversions.Bson;

//Declaring stateless JavaBean named MongoDBAuthenticationBean
@Stateless(name = "MongoDBAuthenticationBean")
public class MongoDBAuthenticationBean {
    //Declaring ConnectionBean to connect to the MongoDB database
    @EJB
    MongoDBConnectionBean MongoDBConnection;

    //Initialising the MongoDB authentication bean
    public MongoDBAuthenticationBean(){

    }

    //Subroutine for finding a student within the database
    public FindIterable<Document> FindStudent(String EmailAddress, String Password){
        //Getting a MongoDB connection
        MongoClient MongoConnection = MongoDBConnection.getMongoClient();

        //Fetching the library database
        MongoDatabase LibraryDatabase = MongoConnection.getDatabase("LibraryDatabase");

        //Fetching the students collection
        MongoCollection<Document> StudentCollection = LibraryDatabase.getCollection("StudentsCollection");

        //Declaring database query that filters the students collection to only show students with matching credentials
        Bson Query = Filters.and(Filters.eq("EmailAddress",EmailAddress),Filters.eq("Password",Password));

        //Applying query to the database
        FindIterable<Document> IsStudentPresent = StudentCollection.find(Query);

        //Returning the result found
        return IsStudentPresent;
    }
}
