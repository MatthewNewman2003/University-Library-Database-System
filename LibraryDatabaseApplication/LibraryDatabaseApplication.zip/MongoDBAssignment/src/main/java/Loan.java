//Importing libraries
import java.io.Serializable;
import java.sql.Date;

//Declaring Loan class
public class Loan implements Serializable{
    //Setting the private variables LoanName, EmailAddress, BookName, LoanDate, DueDate, ReturnDate, ReturnedOnTime and FinePaid
    private String LoanName;
    private String EmailAddress;
    private String BookName;
    private Date LoanDate;
    private Date DueDate;
    private Date ReturnDate;
    private String ReturnedOnTime;
    private String FinePaid;

    //Subroutine for getting LoanName
    public String getLoanName(){
        return LoanName;
    }

    //Subroutine for setting LoanName
    public void setLoanName(String LoanName){ this.LoanName = LoanName; }

    //Subroutine for getting EmailAddress
    public String getEmailAddress(){
        return EmailAddress;
    }

    //Subroutine for setting EmailAddress
    public void setEmailAddress(String Email){
        this.EmailAddress = Email;
    }

    //Subroutine for getting BookName
    public String getBookName(){
        return BookName;
    }

    //Subroutine for setting BookName
    public void setBookName(String BookName){
        this.BookName = BookName;
    }

    //Subroutine for getting LoanDate
    public Date getLoanDate(){
        return LoanDate;
    }

    //Subroutine for setting LoanDate
    public void setLoanDate(Date LoanDate){
        this.LoanDate = LoanDate;
    }

    //Subroutine for getting DueDate
    public Date getDueDate(){
        return DueDate;
    }

    //Subroutine for setting DueDate
    public void setDueDate(Date DueDate){
        this.DueDate = DueDate;
    }

    //Subroutine for getting ReturnDate
    public Date getReturnDate(){ return ReturnDate; }

    //Subroutine for setting ReturnDate
    public void setReturnDate(Date ReturnDate){ this.ReturnDate = ReturnDate;}

    //Subroutine for getting ReturnedOnTime status
    public String getReturnedOnTime(){ return ReturnedOnTime; }

    //Subroutine for setting ReturnedOnTime status
    public void setReturnedOnTime(String ReturnedOnTime){ this.ReturnedOnTime = ReturnedOnTime; }

    //Subroutine for getting FinePaid status
    public String getFinePaid(){ return FinePaid; }

    //Subroutine for setting FinePaid status
    public void setFinePaid(String FinePaid){ this.FinePaid = FinePaid; }
}
