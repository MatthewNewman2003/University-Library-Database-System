//Importing necessary libraries
import com.mongodb.client.*;
import jakarta.ejb.EJB;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.bson.Document;
import java.io.IOException;
import java.util.ArrayList;

//Declaring a web servlet with the name Authentication
@WebServlet(name = "Authentication", value = "/Authentication")
public class Authentication extends HttpServlet {
    //Declaring AuthenticationBeans for MongoDB and Oracle
    @EJB
    MongoDBAuthenticationBean MongoDBStudentAuthentication;
    @EJB
    OracleAuthenticationBean OracleStudentAuthentication;

    //An enumerator of the two data sources within the project
    enum DatabaseType{
        ORACLE, MONGODB;
    }

    //Setting the database type for the servlet
    //By default, this is set to Oracle, but can be changed to MongoDB
    private Authentication.DatabaseType Database = Authentication.DatabaseType.ORACLE;

    //Function for performing GET requests (this is empty, as none are performed here)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    //Function for performing POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Fetching the email address and password parameters from the POST request
        String EmailAddress = request.getParameter("EmailAddress");
        String Password = request.getParameter("Password");

        //Outcome if DatabaseType is set to MongoDB
        if(Database == DatabaseType.MONGODB) {
            //Finding all documents that fit the given email address and password within MongoDB
            FindIterable<Document> FindStudent = MongoDBStudentAuthentication.FindStudent(EmailAddress, Password);
            //Outputting the first student found as the result
            Document Result = FindStudent.first();
            //Outcome if a student is found
            if (Result != null) {
                //Sending the user to the homepage and beginning a session for them
                request.setAttribute("EmailAddress", EmailAddress);
                RequestDispatcher Dispatcher = getServletContext().getRequestDispatcher("/Homepage.jsp");
                Dispatcher.forward(request, response);
                HttpSession session = request.getSession();
                session.setAttribute("EmailAddress", EmailAddress);
            } else {
                //If a student is not found, the user is informed of their invalid credentials and encouraged to input valid ones
                String Message = "These credentials are invalid. Please input valid credentials.";
                request.setAttribute("Message", Message);
                request.getRequestDispatcher("LoginPage.jsp").forward(request, response);
            }
        } else{
            //If the database type is set to Oracle, a Student class is created and details are set
            Student ExistingStudent = new Student();

            //Setting student details based on inputted credentials
            ExistingStudent.setEmailAddress(EmailAddress);
            ExistingStudent.setPassword(Password);

            //Searching the Oracle database for a list of matching students
            ArrayList<Student> MatchingStudent = OracleStudentAuthentication.FindStudent(ExistingStudent);
            //Outcome if no matching students are found
            if(MatchingStudent.isEmpty()){
                //Informing the user of their invalid credentials and encouraging them to provide valid ones
                String Message = "These credentials are invalid. Please input valid credentials.";
                request.setAttribute("Message", Message);
                request.getRequestDispatcher("LoginPage.jsp").forward(request, response);
            } else{
                //If a student with matching credentials is found, the user is sent to the homepage and a session is started for them
                request.setAttribute("EmailAddress", EmailAddress);
                RequestDispatcher Dispatcher = getServletContext().getRequestDispatcher("/Homepage.jsp");
                Dispatcher.forward(request, response);
                HttpSession session = request.getSession();
                session.setAttribute("EmailAddress", EmailAddress);
            }
        }
    }
}