//Importing libraries
import jakarta.annotation.PostConstruct;
import jakarta.ejb.Lock;
import jakarta.ejb.LockType;
import jakarta.ejb.Singleton;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//Declaring Singleton EJB named ConnectionBean
@Singleton(name="ConnectionBean")
public class ConnectionBean {
    public ConnectionBean(){

    }
    //Declaring Oracle connection
    private Connection Connection = null;
    //Subroutine for getting Oracle connection
    @Lock(LockType.READ)
    public Connection getConnection(){
        return Connection;
    }

    //Subroutine for initialising Oracle connection (Oracle details removed)
    @PostConstruct
    public void init(){
        try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch(ClassNotFoundException Exception){
            System.out.println("Oracle driver not found. Connection failed.");
            Exception.printStackTrace();
        }
        try{
            Connection = DriverManager.getConnection(
                    "[ORACLE URL]",
                    "[USERNAME]",
                    "[PASSWORD]"
            );
            if(Connection != null){
                System.out.println("Database connection successful.");
            } else{
                System.out.println("Database connection failed.");
            }
        } catch(SQLException Exception){
            System.out.println("SQL Exception thrown. Connection failed.");
            Exception.printStackTrace();
        }
    }
}
