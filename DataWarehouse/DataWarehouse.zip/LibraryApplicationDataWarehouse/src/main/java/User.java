//Importing Serializable library
import java.io.Serializable;

//Declaring User class with serializable properties
public class User implements Serializable{
    //Declaring Username and Password attributes
    private String Username;
    private String Password;

    //Declaring getter method for Username
    public String getUsername(){ return Username; }

    //Declaring setter method for Username
    public void setUsername(String Username){ this.Username = Username; }

    //Declaring getter method for Password
    public String getPassword(){ return Password; }

    //Declaring setter method for Password
    public void setPassword(String Password){ this.Password = Password; }
}
