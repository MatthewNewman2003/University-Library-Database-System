//Importing variables
import jakarta.ejb.EJB;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.util.ArrayList;

//Declaring servlet named CourseLeaderLoansYear
@WebServlet(name = "CourseLeaderLoansYear", value = "/CourseLeaderLoansYear")
public class CourseLeaderLoansYear extends HttpServlet {
    //Declaring an instance of CourseLeaderLoanBean to connect to the database
    @EJB
    CourseLeaderLoanBean Loans;

    //Declaring subroutine for handling GET requests (none are sent here, so this is empty)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    //Declaring subroutine for handling POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Collecting course and year parameters from request
        String Course = request.getParameter("Course");
        String LoanYearStr = request.getParameter("Year");

        //Converting the inputted year into an integer
        Integer LoanYear = Integer.parseInt(LoanYearStr);

        //Searching for the total number of loans for the given course and year
        ArrayList<LoanTotal> TotalLoansByCourse = Loans.LoansPerYear(Course, LoanYear);
        //If no loans were found, the user is informed of this via a message
        if(TotalLoansByCourse.isEmpty()){
            String Message = "The total amount of relevant loans during this year was: 0";
            request.setAttribute("YearMessage", Message);
            request.getRequestDispatcher("CourseLeaderLoans.jsp").forward(request, response);
        } else{
            //If loans were found, the exact amount is displayed via a message
            LoanTotal TotalLoans = TotalLoansByCourse.get(0);
            String Message = "The total amount of relevant loans during this year was: " + TotalLoans.getTotalLoan();
            request.setAttribute("YearMessage", Message);
            request.getRequestDispatcher("CourseLeaderLoans.jsp").forward(request, response);
        }
    }
}