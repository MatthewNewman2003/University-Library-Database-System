//Importing variables
import jakarta.ejb.EJB;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

//Declaring servlet named ViceChancellorSignupsMonth
@WebServlet(name = "ViceChancellorSignupsMonth", value = "/ViceChancellorSignupsMonth")
public class ViceChancellorSignupsMonth extends HttpServlet {
    //Declaring an instance of ViceChancellorSignupBean to connect to the database
    @EJB
    ViceChancellorSignupBean Signups;

    //Declaring subroutine for handling GET requests (none are sent here, so this is empty)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    //Declaring subroutine for handling POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Collecting month parameter from request
        String SignupMonthStr = request.getParameter("Month");

        //Declaring a null date variable to represent the month
        Date SignupMonth = null;
        //Trying to convert the inputted month string into a date
        //If the string cannot be converted to a date, a parse exception is thrown
        try {
            SimpleDateFormat DateConverter = new SimpleDateFormat("yyyy-MM");
            SignupMonth = DateConverter.parse(SignupMonthStr);
        }catch(ParseException exp){
            exp.printStackTrace();
        }

        //Searching for the total amount of signups for the given month
        ArrayList<SignupTotal> TotalSignupsOverall = Signups.SignupsPerMonth(SignupMonth);
        //If no signups were found, the user is informed of this via a message
        if(TotalSignupsOverall.isEmpty()){
            String Message = "The total amount of signups during this month was: 0";
            request.setAttribute("MonthMessage", Message);
            request.getRequestDispatcher("ViceChancellorSignups.jsp").forward(request, response);
        } else{
            //If signups were found, the exact amount is displayed via a message
            SignupTotal TotalSignups = TotalSignupsOverall.get(0);
            String Message = "The total amount of signups during this month was: " + TotalSignups.getTotalSignups();
            request.setAttribute("MonthMessage", Message);
            request.getRequestDispatcher("ViceChancellorSignups.jsp").forward(request, response);
        }
    }
}
