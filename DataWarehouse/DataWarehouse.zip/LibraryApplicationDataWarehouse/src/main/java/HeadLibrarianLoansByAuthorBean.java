//Importing libraries
import jakarta.ejb.EJB;
import jakarta.ejb.Stateless;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

//Declaring Stateless EJB named HeadLibrarianLoansByAuthorBean
@Stateless(name="HeadLibrarianLoansByAuthorBean")
public class HeadLibrarianLoansByAuthorBean {
    //Declaring instance of ConnectionBean to connect to Oracle
    @EJB
    ConnectionBean Connect;

    //Declaring public initialisation class
    public HeadLibrarianLoansByAuthorBean(){

    }

    //Declaring subroutine to find the amount of relevant loans per month
    public ArrayList<LoanTotal> LoansPerMonth(String Author, Date Month){
        //Declaring calendar instance and setting the inputted month as the time
        Calendar MonthDate = Calendar.getInstance();
        MonthDate.setTime(Month);

        //Extracting month and year integers from the inputted month
        Integer YearOfMonth = MonthDate.get(MonthDate.YEAR);
        Integer MonthOfMonth = MonthDate.get(MonthDate.MONTH) + 1;

        //Declaring SQL query to find the total loan amount of a given author during a given month
        String Query = "SELECT SUM(TotalLoans) AS LoanTotal FROM tblLoansFact_Book WHERE AuthorID IN (SELECT AuthorID FROM tblAuthorsDimension WHERE AuthorName = ?) AND LoanMonth = ? AND LoanYear = ?";

        //Declaring an array list to store the query results
        ArrayList<LoanTotal> TotalLoans = new ArrayList();

        //Trying to execute query
        try{
            //Connecting to Oracle
            Connection OracleConnection = Connect.getConnection();
            //Preparing a prepared statement based on the query above
            PreparedStatement SQLQuery = OracleConnection.prepareStatement(Query);
            //Setting the parameter values of the query
            SQLQuery.setString(1, Author);
            SQLQuery.setInt(2,MonthOfMonth);
            SQLQuery.setInt(3,YearOfMonth);
            //Executing the query and returning the results
            ResultSet Result = SQLQuery.executeQuery();

            //Inputting the value found into the array list
            while(Result.next()){
                //Declaring a new instance of LoanTotal to store the total
                LoanTotal NewLoanTotal = new LoanTotal();
                //Setting the total loan amount of the instance to that found
                NewLoanTotal.setTotalLoan(Result.getInt("LoanTotal"));
                //Adding total to the array list
                TotalLoans.add(NewLoanTotal);
            }

            //Closing the SQL query
            SQLQuery.close();

            //Returning the array list
            return TotalLoans;
        } catch(SQLException SQLError){
            //Outputting the stack trace if an SQL exception is thrown
            System.out.println("SQL Exception thrown");
            SQLError.printStackTrace();
        }
        //Returning the array list
        return TotalLoans;
    }
    //Declaring subroutine to find the amount of relevant loans per month
    public ArrayList<LoanTotal> LoansPerYear(String Author, Integer Year){
        //Declaring SQL query to find the total loan amount of a given author during a given year
        String Query = "SELECT SUM(TotalLoans) AS LoanTotal FROM tblLoansFact_Book WHERE AuthorID IN (SELECT AuthorID FROM tblAuthorsDimension WHERE AuthorName = ?) AND LoanYear = ?";

        //Declaring an array list to store the query results
        ArrayList<LoanTotal> TotalLoans = new ArrayList();

        //Trying to execute query
        try{
            //Connecting to Oracle
            Connection OracleConnection = Connect.getConnection();
            //Preparing a prepared statement based on the query above
            PreparedStatement SQLQuery = OracleConnection.prepareStatement(Query);
            //Setting the parameter values of the query
            SQLQuery.setString(1, Author);
            SQLQuery.setInt(2,Year);
            //Executing the query and returning the results
            ResultSet Result = SQLQuery.executeQuery();

            //Inputting the value found into the array list
            while(Result.next()){
                //Declaring a new instance of LoanTotal to store the total
                LoanTotal NewLoanTotal = new LoanTotal();
                //Setting the total loan amount of the instance to that found
                NewLoanTotal.setTotalLoan(Result.getInt("LoanTotal"));
                //Adding total to the array list
                TotalLoans.add(NewLoanTotal);
            }

            //Closing the SQL query
            SQLQuery.close();

            //Returning the array list
            return TotalLoans;
        } catch(SQLException SQLError){
            //Outputting the stack trace if an SQL exception is thrown
            System.out.println("SQL Exception thrown");
            SQLError.printStackTrace();
        }
        //Returning the array list
        return TotalLoans;
    }
}
