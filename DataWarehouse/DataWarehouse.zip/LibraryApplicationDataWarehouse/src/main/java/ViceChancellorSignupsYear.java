//Importing variables
import jakarta.ejb.EJB;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.util.ArrayList;

//Declaring servlet named ViceChancellorSignupsYear
@WebServlet(name = "ViceChancellorSignupsYear", value = "/ViceChancellorSignupsYear")
public class ViceChancellorSignupsYear extends HttpServlet {
    //Declaring an instance of ViceChancellorSignupBean to connect to the database
    @EJB
    ViceChancellorSignupBean Signups;

    //Declaring subroutine for handling GET requests (none are sent here, so this is empty)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    //Declaring subroutine for handling POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Collecting year parameter from request
        String SignupYearStr = request.getParameter("Year");

        //Converting the inputted year into an integer
        Integer SignupYear = Integer.parseInt(SignupYearStr);

        //Searching for the total amount of signups for the given year
        ArrayList<SignupTotal> TotalSignupsOverall = Signups.SignupsPerYear(SignupYear);
        //If no signups were found, the user is informed of this via a message
        if(TotalSignupsOverall.isEmpty()){
            String Message = "The total amount of signups during this year was: 0";
            request.setAttribute("YearMessage", Message);
            request.getRequestDispatcher("ViceChancellorSignups.jsp").forward(request, response);
        } else{
            //If signups were found, the exact amount is displayed via a message
            SignupTotal TotalSignups = TotalSignupsOverall.get(0);
            String Message = "The total amount of signups during this year was: " + TotalSignups.getTotalSignups();
            request.setAttribute("YearMessage", Message);
            request.getRequestDispatcher("ViceChancellorSignups.jsp").forward(request, response);
        }
    }
}
