//Importing Serializable library
import java.io.Serializable;

//Declaring SignupTotal class
public class SignupTotal implements Serializable{
    //Declaring private variable TotalSignups
    private Integer TotalSignups;

    //Subroutine for getting TotalSignups
    public Integer getTotalSignups(){ return TotalSignups; }

    //Subroutine for setting TotalSignups
    public void setTotalSignups(Integer TotalSignups){ this.TotalSignups = TotalSignups; }
}
