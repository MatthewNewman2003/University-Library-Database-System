//Importing variables
import jakarta.ejb.EJB;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.util.ArrayList;

//Declaring servlet named CourseLeaderFinePaidYear
@WebServlet(name = "CourseLeaderFinePaidYear", value = "/CourseLeaderFinePaidYear")
public class CourseLeaderFinePaidYear extends HttpServlet {
    //Declaring an instance of CourseLeaderFineBean to connect to the database
    @EJB
    CourseLeaderFineBean FinePaid;

    //Declaring subroutine for handling GET requests (none are sent here, so this is empty)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    //Declaring subroutine for handling POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Collecting course and year parameters from request
        String Course = request.getParameter("Course");
        String FineYearStr = request.getParameter("Year");

        //Converting the inputted year into an integer
        Integer FineYear = Integer.parseInt(FineYearStr);

        //Searching for the total amount of fine paid for the given course and year
        ArrayList<FineTotal> TotalFineByCourse = FinePaid.FinePerYear(Course, FineYear);
        //If no loans were found, the user is informed of this via a message
        if(TotalFineByCourse.isEmpty()){
            String Message = "The total amount of relevant fine paid during this year was: £0";
            request.setAttribute("YearMessage", Message);
            request.getRequestDispatcher("CourseLeaderFinePaid.jsp").forward(request, response);
        } else{
            //If loans were found, the exact amount is displayed via a message
            FineTotal TotalFine = TotalFineByCourse.get(0);
            String Message = "The total amount of relevant fine paid during this year was: £" + TotalFine.getTotalFine();
            request.setAttribute("YearMessage", Message);
            request.getRequestDispatcher("CourseLeaderFinePaid.jsp").forward(request, response);
        }
    }
}
