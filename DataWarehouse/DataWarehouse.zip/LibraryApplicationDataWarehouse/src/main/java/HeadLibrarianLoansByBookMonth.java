//Importing variables
import jakarta.ejb.EJB;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

//Declaring servlet named HeadLibrarianLoansByBookMonth
@WebServlet(name = "HeadLibrarianLoansByBookMonth", value = "/HeadLibrarianLoansByBookMonth")
public class HeadLibrarianLoansByBookMonth extends HttpServlet {
    //Declaring an instance of HeadLibrarianLoansByBookBean to connect to the database
    @EJB
    HeadLibrarianLoansByBookBean LoansByBook;

    //Declaring subroutine for handling GET requests (none are sent here, so this is empty)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    //Declaring subroutine for handling POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Collecting book and month parameters from request
        String Book = request.getParameter("Book");
        String LoanMonthStr = request.getParameter("Month");

        //Declaring a null date variable to represent the month
        Date LoanMonth = null;
        //Trying to convert the inputted month string into a date
        //If the string cannot be converted to a date, a parse exception is thrown
        try {
            SimpleDateFormat DateConverter = new SimpleDateFormat("yyyy-MM");
            LoanMonth = DateConverter.parse(LoanMonthStr);
        }catch(ParseException exp){
            exp.printStackTrace();
        }

        //Searching for the total number of loans for the given book and month
        ArrayList<LoanTotal> TotalLoansByBook = LoansByBook.LoansPerMonth(Book, LoanMonth);
        //If no loans were found, the user is informed of this via a message
        if(TotalLoansByBook.isEmpty()){
            String Message = "The total amount of relevant loans during this month was: 0";
            request.setAttribute("MonthMessage", Message);
            request.getRequestDispatcher("HeadLibrarianLoansByBook.jsp").forward(request, response);
        } else{
            //If loans were found, the exact amount is displayed via a message
            LoanTotal TotalLoans = TotalLoansByBook.get(0);
            String Message = "The total amount of relevant loans during this month was: " + TotalLoans.getTotalLoan();
            request.setAttribute("MonthMessage", Message);
            request.getRequestDispatcher("HeadLibrarianLoansByBook.jsp").forward(request, response);
        }
    }
}