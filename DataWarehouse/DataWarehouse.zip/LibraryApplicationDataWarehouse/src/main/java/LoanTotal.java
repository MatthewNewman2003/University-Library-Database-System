//Importing Serializable library
import java.io.Serializable;

//Declaring LoanTotal class
public class LoanTotal implements Serializable{
    //Declaring private variable TotalLoan
    private Integer TotalLoan;

    //Subroutine for getting TotalLoan
    public Integer getTotalLoan(){ return TotalLoan; }

    //Subroutine for setting TotalLoan
    public void setTotalLoan(Integer TotalLoan){ this.TotalLoan = TotalLoan; }
}