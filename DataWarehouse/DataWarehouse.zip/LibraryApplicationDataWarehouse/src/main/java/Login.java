//Importing libraries
import jakarta.ejb.EJB;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.util.ArrayList;

//Declaring servlet named Login
@WebServlet(name = "Login", value = "/Login")
public class Login extends HttpServlet {
    //Declaring instance of LoginBean
    @EJB
    LoginBean Login;

    //Subroutine for handling GET requests (as no GET requests are performed here, this is empty)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    //Subroutine for handling POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Fetching username and password parameters from POST request
        String Username = request.getParameter("Username");
        String Password = request.getParameter("Password");

        //Declaring new instance of User class
        User UserLogin = new User();

        //Setting username and password values of new user to the inputted credentials
        UserLogin.setUsername(Username);
        UserLogin.setPassword(Password);

        //Finding a user with matching credentials
        ArrayList<User> MatchingUser = Login.FindUser(UserLogin);
        //Outcome if no matching user is found
        if(MatchingUser.isEmpty()){
            //Informing the user of their invalid credentials and encouraging them to provide valid ones
            String Message = "These credentials are invalid. Please input valid credentials.";
            request.setAttribute("Message", Message);
            request.getRequestDispatcher("LoginPage.jsp").forward(request, response);
        } else{
            //If a user is found, the username is fetched
            String UserName = UserLogin.getUsername();
            //The user is forwarded to the right homepage for their inputted username
            //For instance, the username HeadLibrarian sees the user forwarded to the head librarian homepage
            if(UserName.equals("HeadLibrarian")){
                RequestDispatcher Dispatcher = getServletContext().getRequestDispatcher("/HeadLibrarianHomepage.jsp");
                Dispatcher.forward(request, response);
            }else if(UserName.equals("CourseLeader")){
                RequestDispatcher Dispatcher = getServletContext().getRequestDispatcher("/CourseLeaderHomepage.jsp");
                Dispatcher.forward(request, response);
            }else{
                RequestDispatcher Dispatcher = getServletContext().getRequestDispatcher("/ViceChancellorHomepage.jsp");
                Dispatcher.forward(request, response);
            }
        }
    }
}