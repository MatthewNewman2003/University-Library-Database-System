//Importing variables
import jakarta.ejb.EJB;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.util.ArrayList;

//Declaring servlet named HeadLibrarianLoansByGenreYear
@WebServlet(name = "HeadLibrarianLoansByGenreYear", value = "/HeadLibrarianLoansByGenreYear")
public class HeadLibrarianLoansByGenreYear extends HttpServlet {
    //Declaring an instance of HeadLibrarianLoansByBookBean to connect to the database
    @EJB
    HeadLibrarianLoansByGenreBean LoansByGenre;

    //Declaring subroutine for handling GET requests (none are sent here, so this is empty)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    //Declaring subroutine for handling POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Collecting genre and year parameters from request
        String Genre = request.getParameter("Genre");
        String LoanYearStr = request.getParameter("Year");

        //Converting the inputted year into an integer
        Integer LoanYear = Integer.parseInt(LoanYearStr);

        //Searching for the total number of loans for the given book and year
        ArrayList<LoanTotal> TotalLoansByBook = LoansByGenre.LoansPerYear(Genre, LoanYear);
        //If no loans were found, the user is informed of this via a message
        if(TotalLoansByBook.isEmpty()){
            String Message = "The total amount of relevant loans during this year was: 0";
            request.setAttribute("YearMessage", Message);
            request.getRequestDispatcher("HeadLibrarianLoansByGenre.jsp").forward(request, response);
        } else{
            //If loans were found, the exact amount is displayed via a message
            LoanTotal TotalLoans = TotalLoansByBook.get(0);
            String Message = "The total amount of relevant loans during this year was: " + TotalLoans.getTotalLoan();
            request.setAttribute("YearMessage", Message);
            request.getRequestDispatcher("HeadLibrarianLoansByGenre.jsp").forward(request, response);
        }
    }
}