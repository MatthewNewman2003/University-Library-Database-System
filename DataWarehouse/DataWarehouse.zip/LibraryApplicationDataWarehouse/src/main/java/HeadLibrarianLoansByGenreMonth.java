//Importing variables
import jakarta.ejb.EJB;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

//Declaring servlet named HeadLibrarianLoansByGenreMonth
@WebServlet(name = "HeadLibrarianLoansByGenreMonth", value = "/HeadLibrarianLoansByGenreMonth")
public class HeadLibrarianLoansByGenreMonth extends HttpServlet {
    //Declaring an instance of HeadLibrarianLoansByGenreBean to connect to the database
    @EJB
    HeadLibrarianLoansByGenreBean LoansByGenre;

    //Declaring subroutine for handling GET requests (none are sent here, so this is empty)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    //Declaring subroutine for handling POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Collecting genre and month parameters from request
        String Genre = request.getParameter("Genre");
        String LoanMonthStr = request.getParameter("Month");

        //Declaring a null date variable to represent the month
        Date LoanMonth = null;
        //Trying to convert the inputted month string into a date
        //If the string cannot be converted to a date, a parse exception is thrown
        try {
            SimpleDateFormat DateConverter = new SimpleDateFormat("yyyy-MM");
            LoanMonth = DateConverter.parse(LoanMonthStr);
        }catch(ParseException exp){
            exp.printStackTrace();
        }

        //Searching for the total number of loans for the given genre and month
        ArrayList<LoanTotal> TotalLoansByGenre = LoansByGenre.LoansPerMonth(Genre, LoanMonth);
        //If no loans were found, the user is informed of this via a message
        if(TotalLoansByGenre.isEmpty()){
            String Message = "The total amount of relevant loans during this month was: 0";
            request.setAttribute("MonthMessage", Message);
            request.getRequestDispatcher("HeadLibrarianLoansByGenre.jsp").forward(request, response);
        } else{
            //If loans were found, the exact amount is displayed via a message
            LoanTotal TotalLoans = TotalLoansByGenre.get(0);
            String Message = "The total amount of relevant loans during this month was: " + TotalLoans.getTotalLoan();
            request.setAttribute("MonthMessage", Message);
            request.getRequestDispatcher("HeadLibrarianLoansByGenre.jsp").forward(request, response);
        }
    }
}
