//Importing variables
import jakarta.ejb.EJB;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.util.ArrayList;

//Declaring servlet named ViceChancellorLoansYear
@WebServlet(name = "ViceChancellorLoansYear", value = "/ViceChancellorLoansYear")
public class ViceChancellorLoansYear extends HttpServlet {
    //Declaring an instance of ViceChancellorLoanBean to connect to the database
    @EJB
    ViceChancellorLoanBean Loans;

    //Declaring subroutine for handling GET requests (none are sent here, so this is empty)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    //Declaring subroutine for handling POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Collecting year parameter from request
        String LoanYearStr = request.getParameter("Year");

        //Converting the inputted year into an integer
        Integer LoanYear = Integer.parseInt(LoanYearStr);

        //Searching for the total number of loans for the given year
        ArrayList<LoanTotal> TotalLoansOverall = Loans.LoansPerYear(LoanYear);
        //If no loans were found, the user is informed of this via a message
        if(TotalLoansOverall.isEmpty()){
            String Message = "The total amount of loans during this year was: 0";
            request.setAttribute("YearMessage", Message);
            request.getRequestDispatcher("ViceChancellorLoans.jsp").forward(request, response);
        } else{
            //If loans were found, the exact amount is displayed via a message
            LoanTotal TotalLoans = TotalLoansOverall.get(0);
            String Message = "The total amount of loans during this year was: " + TotalLoans.getTotalLoan();
            request.setAttribute("YearMessage", Message);
            request.getRequestDispatcher("ViceChancellorLoans.jsp").forward(request, response);
        }
    }
}

