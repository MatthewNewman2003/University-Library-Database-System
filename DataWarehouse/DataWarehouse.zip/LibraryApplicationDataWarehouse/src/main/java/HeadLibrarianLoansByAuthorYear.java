//Importing variables
import jakarta.ejb.EJB;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.util.ArrayList;

//Declaring servlet named HeadLibrarianLoansByAuthorYear
@WebServlet(name = "HeadLibrarianLoansByAuthorYear", value = "/HeadLibrarianLoansByAuthorYear")
public class HeadLibrarianLoansByAuthorYear extends HttpServlet {
    //Declaring an instance of HeadLibrarianLoansByAuthorBean to connect to the database
    @EJB
    HeadLibrarianLoansByAuthorBean LoansByAuthor;

    //Declaring subroutine for handling GET requests (none are sent here, so this is empty)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    //Declaring subroutine for handling POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Collecting author and year parameters from request
        String Author = request.getParameter("Author");
        String LoanYearStr = request.getParameter("Year");

        //Converting the inputted year into an integer
        Integer LoanYear = Integer.parseInt(LoanYearStr);

        //Searching for the total number of loans for the given author and year
        ArrayList<LoanTotal> TotalLoansByAuthor = LoansByAuthor.LoansPerYear(Author, LoanYear);
        //If no loans were found, the user is informed of this via a message
        if(TotalLoansByAuthor.isEmpty()){
            String Message = "The total amount of relevant loans during this year was: 0";
            request.setAttribute("YearMessage", Message);
            request.getRequestDispatcher("HeadLibrarianLoansByAuthor.jsp").forward(request, response);
        } else{
            //If loans were found, the exact amount is displayed via a message
            LoanTotal TotalLoans = TotalLoansByAuthor.get(0);
            String Message = "The total amount of relevant loans during this year was: " + TotalLoans.getTotalLoan();
            request.setAttribute("YearMessage", Message);
            request.getRequestDispatcher("HeadLibrarianLoansByAuthor.jsp").forward(request, response);
        }
    }
}