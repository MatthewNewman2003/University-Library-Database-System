//Importing libraries
import jakarta.ejb.EJB;
import jakarta.ejb.Stateless;
import java.sql.*;
import java.util.ArrayList;

//Declaring Stateless EJB named LoginBean
@Stateless(name="LoginBean")
public class LoginBean {
    //Providing Oracle connection
    @EJB
    ConnectionBean DatabaseConnection;

    //Initialising the LoginBean within a class
    public LoginBean(){

    }

    //Subroutine to find a user
    public ArrayList<User> FindUser(User UserLogin){
        //Declaring SQL query
        String UserSearch = "SELECT * FROM DWUsers WHERE Username=? AND Password=?";

        //Declaring an ArrayList to store the query results
        ArrayList Results = new ArrayList();
        try{
            //Getting a database connection, preparing an SQL query and assigning variable values
            Connection DBConnection = DatabaseConnection.getConnection();
            PreparedStatement SearchQuery = DBConnection.prepareStatement(UserSearch);
            SearchQuery.setString(1, UserLogin.getUsername());
            SearchQuery.setString(2, UserLogin.getPassword());
            ResultSet Result = SearchQuery.executeQuery();

            //Adding each new user found to the Results array list
            while(Result.next()){
                User FoundUser = new User();
                FoundUser.setUsername(Result.getString("Username"));
                FoundUser.setPassword(Result.getString("Password"));
                Results.add(FoundUser);
            }

            //Closing the query
            SearchQuery.close();

            //Returning query result
            return Results;
        } catch(SQLException Exception){
            //Outcome if an SQL exception occurs
            System.out.println("SQL Exception occurred.");
            Exception.printStackTrace();
        }
        //Returning query result
        return Results;
    }
}
