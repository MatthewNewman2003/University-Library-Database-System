//Importing variables
import jakarta.ejb.EJB;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.util.ArrayList;

//Declaring servlet named CourseLeaderSignupsYear
@WebServlet(name = "CourseLeaderSignupsYear", value = "/CourseLeaderSignupsYear")
public class CourseLeaderSignupsYear extends HttpServlet {
    //Declaring an instance of CourseLeaderSignupBean to connect to the database
    @EJB
    CourseLeaderSignupBean Signups;

    //Declaring subroutine for handling GET requests (none are sent here, so this is empty)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    //Declaring subroutine for handling POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Collecting course and year parameters from request
        String Course = request.getParameter("Course");
        String SignupYearStr = request.getParameter("Year");

        //Converting the inputted year into an integer
        Integer SignupYear = Integer.parseInt(SignupYearStr);

        //Searching for the total amount of signups for the given course and month
        ArrayList<SignupTotal> TotalSignupsByCourse = Signups.SignupsPerYear(Course, SignupYear);
        //If no signups were found, the user is informed of this via a message
        if(TotalSignupsByCourse.isEmpty()){
            String Message = "The total amount of relevant signups during this year was: 0";
            request.setAttribute("YearMessage", Message);
            request.getRequestDispatcher("CourseLeaderSignups.jsp").forward(request, response);
        } else{
            //If signups were found, the exact amount is displayed via a message
            SignupTotal TotalSignups = TotalSignupsByCourse.get(0);
            String Message = "The total amount of relevant signups during this year was: " + TotalSignups.getTotalSignups();
            request.setAttribute("YearMessage", Message);
            request.getRequestDispatcher("CourseLeaderSignups.jsp").forward(request, response);
        }
    }
}

