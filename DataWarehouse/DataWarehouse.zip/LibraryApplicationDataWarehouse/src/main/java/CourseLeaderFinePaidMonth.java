//Importing variables
import jakarta.ejb.EJB;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

//Declaring servlet named CourseLeaderFinePaidMonth
@WebServlet(name = "CourseLeaderFinePaidMonth", value = "/CourseLeaderFinePaidMonth")
public class CourseLeaderFinePaidMonth extends HttpServlet {
    //Declaring an instance of CourseLeaderFineBean to connect to the database
    @EJB
    CourseLeaderFineBean FinePaid;

    //Declaring subroutine for handling GET requests (none are sent here, so this is empty)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    //Declaring subroutine for handling POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Collecting course and month parameters from request
        String Course = request.getParameter("Course");
        String FineMonthStr = request.getParameter("Month");

        //Declaring a null date variable to represent the month
        Date FineMonth = null;
        //Trying to convert the inputted month string into a date
        //If the string cannot be converted to a date, a parse exception is thrown
        try {
            SimpleDateFormat DateConverter = new SimpleDateFormat("yyyy-MM");
            FineMonth = DateConverter.parse(FineMonthStr);
        }catch(ParseException exp){
            exp.printStackTrace();
        }

        //Searching for the total amount of fine paid for the given course and month
        ArrayList<FineTotal> TotalFineByCourse = FinePaid.FinePerMonth(Course, FineMonth);
        //If no fines were found, the user is informed of this via a message
        if(TotalFineByCourse.isEmpty()){
            String Message = "The total amount of relevant fine paid during this month was: £0";
            request.setAttribute("MonthMessage", Message);
            request.getRequestDispatcher("CourseLeaderFinePaid.jsp").forward(request, response);
        } else{
            //If fines were found, the exact amount of fine paid is displayed via a message
            FineTotal TotalFine = TotalFineByCourse.get(0);
            String Message = "The total amount of relevant fine paid during this month was: £" + TotalFine.getTotalFine();
            request.setAttribute("MonthMessage", Message);
            request.getRequestDispatcher("CourseLeaderFinePaid.jsp").forward(request, response);
        }
    }
}
