//Importing variables
import jakarta.ejb.EJB;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

//Declaring servlet named ViceChancellorFinePaidMonth
@WebServlet(name = "ViceChancellorFinePaidMonth", value = "/ViceChancellorFinePaidMonth")
public class ViceChancellorFinePaidMonth extends HttpServlet {
    //Declaring an instance of ViceChancellorFineBean to connect to the database
    @EJB
    ViceChancellorFineBean FinePaid;

    //Declaring subroutine for handling GET requests (none are sent here, so this is empty)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    //Declaring subroutine for handling POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Collecting month parameter from request
        String FineMonthStr = request.getParameter("Month");

        //Declaring a null date variable to represent the month
        Date FineMonth = null;
        //Trying to convert the inputted month string into a date
        //If the string cannot be converted to a date, a parse exception is thrown
        try {
            SimpleDateFormat DateConverter = new SimpleDateFormat("yyyy-MM");
            FineMonth = DateConverter.parse(FineMonthStr);
        }catch(ParseException exp){
            exp.printStackTrace();
        }

        //Searching for the total amount of fine paid for the given month
        ArrayList<FineTotal> TotalFineOverall = FinePaid.FinePerMonth(FineMonth);
        //If no fines were found, the user is informed of this via a message
        if(TotalFineOverall.isEmpty()){
            String Message = "The total amount of fine paid during this month was: £0";
            request.setAttribute("MonthMessage", Message);
            request.getRequestDispatcher("ViceChancellorFinePaid.jsp").forward(request, response);
        } else{
            //If fines were found, the exact amount of fine paid is displayed via a message
            FineTotal TotalFine = TotalFineOverall.get(0);
            String Message = "The total amount of fine paid during this month was: £" + TotalFine.getTotalFine();
            request.setAttribute("MonthMessage", Message);
            request.getRequestDispatcher("ViceChancellorFinePaid.jsp").forward(request, response);
        }
    }
}

