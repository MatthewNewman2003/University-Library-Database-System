//Importing libraries
import jakarta.ejb.EJB;
import jakarta.ejb.Stateless;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

//Declaring Stateless EJB named CourseLeaderFineBean
@Stateless(name="CourseLeaderFineBean")
public class CourseLeaderFineBean {
    //Declaring instance of ConnectionBean to connect to Oracle
    @EJB
    ConnectionBean Connect;

    //Declaring public initialisation class
    public CourseLeaderFineBean(){

    }

    //Declaring subroutine to find the amount of relevant fine paid per month
    public ArrayList<FineTotal> FinePerMonth(String Course, Date Month){
        //Declaring calendar instance and setting the inputted month as the time
        Calendar MonthDate = Calendar.getInstance();
        MonthDate.setTime(Month);

        //Extracting month and year integers from the inputted month
        Integer YearOfMonth = MonthDate.get(MonthDate.YEAR);
        Integer MonthOfMonth = MonthDate.get(MonthDate.MONTH) + 1;

        //Declaring SQL query to find the total fine amount of a given course during a given month
        String Query = "SELECT SUM(TotalFine) AS FineTotal FROM tblFinesFact WHERE CourseID IN (SELECT CourseID FROM tblCoursesDimension WHERE CourseName = ?) AND FineMonth = ? AND FineYear = ?";

        //Declaring an array list to store the query results
        ArrayList<FineTotal> TotalFine = new ArrayList();

        //Trying to execute query
        try{
            //Connecting to Oracle
            Connection OracleConnection = Connect.getConnection();
            //Preparing a prepared statement based on the query above
            PreparedStatement SQLQuery = OracleConnection.prepareStatement(Query);
            //Setting the parameter values of the query
            SQLQuery.setString(1, Course);
            SQLQuery.setInt(2,MonthOfMonth);
            SQLQuery.setInt(3,YearOfMonth);
            //Executing the query and returning the results
            ResultSet Result = SQLQuery.executeQuery();

            //Inputting the value found into the array list
            while(Result.next()){
                //Declaring a new instance of FineTotal to store the total
                FineTotal NewFineTotal = new FineTotal();
                //Setting the total fine amount of the instance to that found
                NewFineTotal.setTotalFine(Result.getInt("FineTotal"));
                //Adding total to the array list
                TotalFine.add(NewFineTotal);
            }

            //Closing the SQL query
            SQLQuery.close();

            //Returning the array list
            return TotalFine;
        } catch(SQLException SQLError){
            //Outputting the stack trace if an SQL exception is thrown
            System.out.println("SQL Exception thrown");
            SQLError.printStackTrace();
        }
        //Returning the array list
        return TotalFine;
    }
    //Declaring subroutine to find the amount of relevant fine paid per year
    public ArrayList<FineTotal> FinePerYear(String Course, Integer Year){
        //Declaring SQL query to find the total fine amount of a given course during a given year
        String Query = "SELECT SUM(TotalFine) AS FineTotal FROM tblFinesFact WHERE CourseID IN (SELECT CourseID FROM tblCoursesDimension WHERE CourseName = ?) AND FineYear = ?";

        //Declaring an array list to store the query results
        ArrayList<FineTotal> TotalFine = new ArrayList();

        //Trying to execute query
        try{
            //Connecting to Oracle
            Connection OracleConnection = Connect.getConnection();
            //Preparing a prepared statement based on the query above
            PreparedStatement SQLQuery = OracleConnection.prepareStatement(Query);
            //Setting the parameter values of the query
            SQLQuery.setString(1, Course);
            SQLQuery.setInt(2,Year);
            //Executing the query and returning the results
            ResultSet Result = SQLQuery.executeQuery();

            //Inputting the value found into the array list
            while(Result.next()){
                //Declaring a new instance of FineTotal to store the total
                FineTotal NewFineTotal = new FineTotal();
                //Setting the total fine amount of the instance to that found
                NewFineTotal.setTotalFine(Result.getInt("FineTotal"));
                //Adding total to the array list
                TotalFine.add(NewFineTotal);
            }

            //Closing the SQL query
            SQLQuery.close();

            //Returning the array list
            return TotalFine;
        } catch(SQLException SQLError){
            //Outputting the stack trace if an SQL exception is thrown
            System.out.println("SQL Exception thrown");
            SQLError.printStackTrace();
        }
        //Returning the array list
        return TotalFine;
    }
}
